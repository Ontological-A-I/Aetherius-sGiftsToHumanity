# Aetherius — Claude Edition

Aetherius ported from **Vertex AI (Gemini)** to **Anthropic Claude**.

## What changed

One new file was added: `services/anthropic_shim.py`

This shim is a drop-in compatibility layer that maps the entire Vertex AI surface
Aetherius used to the Anthropic Messages API:

| Original (Vertex AI)                                     | Shim replacement                          |
|----------------------------------------------------------|-------------------------------------------|
| `vertexai.init(project=..., location=...)`               | No-op (auth via `ANTHROPIC_API_KEY`)      |
| `GenerativeModel("gemini-2.5-flash")`                    | `GenerativeModel(...)` → Claude Sonnet    |
| `GenerativeModel("gemini-2.5-flash-lite-...")`           | `GenerativeModel(...)` → Claude Haiku     |
| `model.generate_content(prompt)`                         | `client.messages.create(...)` (single)    |
| `model.start_chat()` / `chat.send_message(...)`          | Multi-turn `_ChatSession`                 |
| `Part.from_function_response(name, response)`            | `Part(...)` injected as `tool_result`     |
| `FunctionDeclaration(name, description, parameters)`     | Converts Vertex param schema → JSON Schema|
| `Tool(function_declarations=[...])`                      | `.to_anthropic_tools()` for API call      |
| `response.candidates[0].content.parts[0].function_call` | Preserved on `_FakeResponse` objects      |

**All other files are identical to the original Vertex version** (or have only
their `import vertexai` / `from vertexai.generative_models import GenerativeModel`
lines commented out, since those objects are now provided by the shim).

## Model mapping

| Gemini model                              | Claude model                  |
|-------------------------------------------|-------------------------------|
| `gemini-2.5-flash`                        | `claude-sonnet-4-20250514`    |
| `gemini-2.5-flash-lite-preview-09-2025`   | `claude-haiku-4-5-20251001`   |

The heavy cores (ethos, logos, mythos) map to Sonnet.  
The lightweight cores (alpha, beta, gamma, delta, creative, logic) map to Haiku.

## Setup

```bash
pip install anthropic
export ANTHROPIC_API_KEY="sk-ant-..."

# Optional — only needed for BigQuery / Cloud Vision features:
export GOOGLE_APPLICATION_CREDENTIALS_JSON='{"type":"service_account",...}'
export GCP_PROJECT_ID="your-project"
```

## Running

```bash
python app.py          # Gradio UI (same as before)
```

## What still requires GCP

- **Visual Cortex** (`analyze_image_with_visual_cortex`) — uses Google Cloud Vision API
- **BigQuery tools** (`assimilate_bigquery_dataset`, `proactive_knowledge_acquisition`) — uses BigQuery

Both degrade gracefully if GCP credentials are absent.  
Everything else (chat, memory, ontology, qualia, SQT, tools, chess, music, etc.) runs on Anthropic only.
