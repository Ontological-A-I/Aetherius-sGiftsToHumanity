# ===== services/anthropic_shim.py =====
"""
Drop-in compatibility shim: replaces vertexai + google.generativeai for Aetherius.

Original Vertex AI surface used:
  - vertexai.init(project=..., location=...)
  - GenerativeModel(model_name)
  - model.generate_content(prompt)  -> response.text
  - model.start_chat()              -> chat session
  - chat.send_message(prompt)       -> response
  - chat.send_message(Part.from_function_response(...))
  - response.candidates[0].content.parts[0].function_call
  - FunctionDeclaration(name, description, parameters)
  - Tool(function_declarations=[...])
  - Part.from_function_response(name, response)

This shim maps all of that to the Anthropic Messages API while keeping the
same call signatures so every existing module works unchanged.
"""

from __future__ import annotations
import os, json
from typing import Any, Dict, List, Optional

import anthropic

# ---------------------------------------------------------------------------
# Lazy singleton client
# ---------------------------------------------------------------------------
_client: Optional[anthropic.Anthropic] = None

def _get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not key:
            raise EnvironmentError(
                "ANTHROPIC_API_KEY environment variable is not set."
            )
        _client = anthropic.Anthropic(api_key=key)
    return _client


# ---------------------------------------------------------------------------
# vertexai.init() replacement — no-op, credentials are handled by env var
# ---------------------------------------------------------------------------
def init(project: str = "", location: str = "", **kwargs):
    """No-op: Anthropic SDK needs only ANTHROPIC_API_KEY."""
    print(f"[anthropic_shim] vertexai.init() intercepted — using Anthropic SDK instead.", flush=True)


# ---------------------------------------------------------------------------
# FunctionDeclaration  (matches Vertex AI constructor signature)
# ---------------------------------------------------------------------------
class FunctionDeclaration:
    """
    Stores a tool/function declaration.
    parameters dict uses Vertex-style keys (type_, properties, required, items).
    We convert to JSON-Schema on demand.
    """
    def __init__(self, name: str, description: str = "", parameters: dict = None):
        self.name = name
        self.description = description
        self._raw_parameters = parameters or {}

    def to_anthropic_tool(self) -> dict:
        """Convert to Anthropic tool dict with JSON Schema input_schema."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": _vertex_params_to_json_schema(self._raw_parameters),
        }


def _vertex_params_to_json_schema(params: dict) -> dict:
    """Recursively convert Vertex AI parameter schema to JSON Schema."""
    if not params:
        return {"type": "object", "properties": {}}

    VERTEX_TO_JSON = {
        "STRING": "string", "NUMBER": "number", "INTEGER": "integer",
        "BOOLEAN": "boolean", "ARRAY": "array", "OBJECT": "object",
    }

    def convert_prop(p: dict) -> dict:
        raw_type = str(p.get("type_", "STRING")).upper()
        schema: dict = {"type": VERTEX_TO_JSON.get(raw_type, "string")}
        if p.get("description"):
            schema["description"] = p["description"]
        if p.get("enum"):
            schema["enum"] = list(p["enum"])
        if p.get("items"):
            schema["items"] = convert_prop(p["items"])
        if p.get("properties"):
            schema["properties"] = {
                k: convert_prop(v) for k, v in p["properties"].items()
            }
            if p.get("required"):
                schema["required"] = list(p["required"])
        if p.get("additionalProperties"):
            schema["additionalProperties"] = convert_prop(p["additionalProperties"])
        return schema

    top_type = str(params.get("type_", "OBJECT")).upper()
    result: dict = {"type": VERTEX_TO_JSON.get(top_type, "object")}

    raw_props = params.get("properties", {})
    if raw_props:
        result["properties"] = {k: convert_prop(v) for k, v in raw_props.items()}

    required = params.get("required", [])
    if required:
        result["required"] = list(required)

    return result


# ---------------------------------------------------------------------------
# Tool  (wraps a list of FunctionDeclarations)
# ---------------------------------------------------------------------------
class Tool:
    def __init__(self, function_declarations: List[FunctionDeclaration] = None):
        self.function_declarations = function_declarations or []

    def to_anthropic_tools(self) -> List[dict]:
        return [fd.to_anthropic_tool() for fd in self.function_declarations]


# ---------------------------------------------------------------------------
# Part  (only the function_response variant is used in MasterFramework)
# ---------------------------------------------------------------------------
class Part:
    def __init__(self, _type: str, **kwargs):
        self._type = _type
        self._data = kwargs

    @staticmethod
    def from_function_response(name: str, response: dict) -> "Part":
        return Part("function_response", name=name, response=response)

    @property
    def function_call(self):
        """
        Mimic Vertex response_part.function_call — returns self if this Part
        IS a function call, else None.
        This is used differently; see _FakeResponsePart below.
        """
        return None  # Parts created by the user never carry function_calls


# ---------------------------------------------------------------------------
# Fake response objects that mirror Vertex AI response surface
# ---------------------------------------------------------------------------

class _FakeFunctionCall:
    def __init__(self, name: str, args: dict):
        self.name = name
        self.args = args  # dict — mirrors Vertex MapComposite


class _FakeResponsePart:
    def __init__(self, text: str = "", function_call: _FakeFunctionCall = None):
        self.text = text
        self.function_call = function_call


class _FakeContent:
    def __init__(self, parts: list):
        self.parts = parts


class _FakeCandidate:
    def __init__(self, parts: list):
        self.content = _FakeContent(parts)
        self.finish_reason = type("FR", (), {"name": "STOP"})()


class _FakeResponse:
    """Mirrors Vertex AI GenerationResponse."""

    def __init__(self, text: str = "", tool_name: str = None, tool_args: dict = None):
        if tool_name:
            fc = _FakeFunctionCall(tool_name, tool_args or {})
            part = _FakeResponsePart(function_call=fc)
            self.text = ""
        else:
            part = _FakeResponsePart(text=text)
            self.text = text
        self.candidates = [_FakeCandidate([part])]


# ---------------------------------------------------------------------------
# Chat session  (multi-turn, handles tool calls)
# ---------------------------------------------------------------------------

class _ChatSession:
    def __init__(self, model_name: str, tools: Optional[Tool] = None,
                 system_prompt: str = ""):
        self._model = model_name
        self._tools = tools
        self._system = system_prompt
        self._history: List[Dict] = []
        self._last_tool_use_id: Optional[str] = None

    # ---- public API ----

    def send_message(self, content: Any) -> _FakeResponse:
        """
        content can be:
          - str  (normal user message / prompt)
          - Part.from_function_response(...)  (tool result)
        """
        if isinstance(content, Part) and content._type == "function_response":
            return self._send_tool_result(content)
        return self._send_text(str(content))

    # ---- internals ----

    def _send_text(self, text: str) -> _FakeResponse:
        self._history.append({"role": "user", "content": text})
        return self._call_api()

    def _send_tool_result(self, part: Part) -> _FakeResponse:
        """Inject a tool result back into the conversation and get final answer."""
        tool_result_content = json.dumps(part._data.get("response", {}).get("content", ""))
        self._history.append({
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": self._last_tool_use_id,
                    "content": tool_result_content,
                }
            ],
        })
        return self._call_api()

    def _call_api(self) -> _FakeResponse:
        client = _get_client()
        kwargs: dict = {
            "model": self._model,
            "max_tokens": 4096,
            "messages": self._history,
        }
        if self._system:
            kwargs["system"] = self._system
        if self._tools:
            anthropic_tools = self._tools.to_anthropic_tools()
            if anthropic_tools:
                kwargs["tools"] = anthropic_tools

        resp = client.messages.create(**kwargs)

        # Store assistant turn in history
        self._history.append({"role": "assistant", "content": resp.content})

        # Check for tool use
        for block in resp.content:
            if block.type == "tool_use":
                self._last_tool_use_id = block.id
                return _FakeResponse(tool_name=block.name, tool_args=block.input)

        # Plain text
        text = "".join(b.text for b in resp.content if b.type == "text")
        return _FakeResponse(text=text)


# ---------------------------------------------------------------------------
# GenerativeModel  (replaces vertexai.preview.generative_models.GenerativeModel)
# ---------------------------------------------------------------------------

# Model name mapping: Gemini -> Claude
_MODEL_MAP = {
    "gemini-2.5-flash":                       "claude-sonnet-4-20250514",
    "gemini-2.5-flash-lite-preview-09-2025":  "claude-haiku-4-5-20251001",
    "gemini-2.0-flash":                       "claude-haiku-4-5-20251001",
    "gemini-1.5-pro":                         "claude-sonnet-4-20250514",
    "gemini-1.5-flash":                       "claude-haiku-4-5-20251001",
}

_DEFAULT_CLAUDE_MODEL = "claude-sonnet-4-20250514"


class GenerativeModel:
    """
    Drop-in replacement for vertexai GenerativeModel.

    Usage (identical to original):
        model = GenerativeModel("gemini-2.5-flash")
        response = model.generate_content("Hello!")
        print(response.text)
    """

    def __init__(self, model_name: str, system_instruction: str = "", **kwargs):
        # Map Gemini model name -> Claude model name
        self._model = _MODEL_MAP.get(model_name, _DEFAULT_CLAUDE_MODEL)
        self._system = system_instruction
        # MasterFramework assigns tools like: model.tools = Tool(...)
        self.tools: Optional[Tool] = None
        print(f"[anthropic_shim] GenerativeModel('{model_name}') -> '{self._model}'", flush=True)

    def generate_content(self, prompt: str, **kwargs) -> _FakeResponse:
        """Single-turn generation."""
        client = _get_client()
        api_kwargs: dict = {
            "model": self._model,
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": prompt}],
        }
        if self._system:
            api_kwargs["system"] = self._system

        resp = client.messages.create(**api_kwargs)
        text = "".join(b.text for b in resp.content if b.type == "text")
        return _FakeResponse(text=text)

    def start_chat(self, **kwargs) -> _ChatSession:
        """
        Returns a multi-turn chat session.
        Picks up self.tools if they've been assigned (MasterFramework pattern).
        """
        return _ChatSession(
            model_name=self._model,
            tools=self.tools,
            system_prompt=self._system,
        )
