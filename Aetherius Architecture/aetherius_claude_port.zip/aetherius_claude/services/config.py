# ===== services/config.py  (Anthropic/Claude Edition) =====
import os

# ── Anthropic ──────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# ── Optional tools ─────────────────────────────────────────────────────────
WOLFRAM_APP_ID   = os.environ.get("WOLFRAM_APP_ID", "")

# ── Storage paths ──────────────────────────────────────────────────────────
DATA_DIR    = os.environ.get("DATA_DIR",    "/data/Memories")
LIBRARY_DIR = os.environ.get("LIBRARY_DIR", "/data/My_AI_Library")

# ── GCP stubs (kept so imports don't break; unused at runtime) ─────────────
# These were used for Vertex AI init and BigQuery.
# Set them if you still want BigQuery tool support; otherwise leave blank.
GCP_PROJECT_ID = os.environ.get("GCP_PROJECT_ID", "")
GCP_LOCATION   = os.environ.get("GCP_LOCATION",   "us-central1")
