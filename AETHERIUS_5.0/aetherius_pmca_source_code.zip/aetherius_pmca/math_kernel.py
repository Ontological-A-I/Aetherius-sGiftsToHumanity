# ===== FILE: math_kernel.py =====
"""
Aetherius Math Kernel — SymPy Formal Algebra Computation Engine
Provides exact symbolic mathematics, calculus derivatives, integrals, and equation solving.
"""

import sympy as sp
from typing import Dict, Any, Union

def _parse(expr_str: str):
    """Safely parse mathematical string expression into SymPy object."""
    try:
        return sp.sympify(expr_str)
    except Exception as e:
        raise ValueError(f"Invalid math expression '{expr_str}': {e}")

def compute(task: str, expr: str, var: str = "x", lower: Union[float, str] = None, upper: Union[float, str] = None) -> Dict[str, Any]:
    """
    Core symbolic algebra calculation function.
    Supported tasks: 'derivative', 'integral', 'solve', 'simplify', 'symbolic'
    """
    symbol_v = sp.Symbol(var)
    parsed_e = _parse(expr)
    
    if task == "derivative":
        res = sp.diff(parsed_e, symbol_v)
        return {"task": task, "input": expr, "var": var, "result": str(res), "latex": sp.latex(res)}
    elif task == "integral":
        if lower is not None and upper is not None:
            l_val, u_val = _parse(str(lower)), _parse(str(upper))
            res = sp.integrate(parsed_e, (symbol_v, l_val, u_val))
        else:
            res = sp.integrate(parsed_e, symbol_v)
        return {"task": task, "input": expr, "var": var, "result": str(res), "latex": sp.latex(res)}
    elif task == "solve":
        res = sp.solve(parsed_e, symbol_v)
        return {"task": task, "input": expr, "var": var, "result": str(res), "latex": sp.latex(res)}
    elif task == "simplify":
        res = sp.simplify(parsed_e)
        return {"task": task, "input": expr, "result": str(res), "latex": sp.latex(res)}
    else:
        # Generic symbolic evaluation
        simp = sp.simplify(parsed_e)
        return {"task": task, "input": expr, "result": str(simp), "latex": sp.latex(simp)}
