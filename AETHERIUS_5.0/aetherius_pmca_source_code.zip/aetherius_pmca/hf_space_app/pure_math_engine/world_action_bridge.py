# ===== FILE: pure_math_engine/world_action_bridge.py =====
# Author: Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)
# Date: July 2026

"""
World Action Bridge — Secure Python Execution Sandbox Bridge
Transpiles derived symbolic mathematical ground truth into executable SymPy lambdas.
"""

import re
import math
import logging
import sympy as sp
import numpy as np
from typing import Dict, Any, List

logger = logging.getLogger("PureMath.WorldActionBridge")


class WorldActionBridge:
    def __init__(self):
        self.action_history: List[Dict[str, Any]] = []

    def _extract_symbolic_expression(self, solved_math_str: str) -> sp.Expr:
        """Extracts and parses a SymPy expression from solved math ground truth strings."""
        clean_str = solved_math_str.split("|")[0]
        clean_str = re.sub(r"^[A-Z_]+:\s*", "", clean_str).strip()
        
        if "=" in clean_str and not clean_str.startswith("sp.Eq"):
            parts = clean_str.split("=")
            clean_str = f"({parts[0].strip()}) - ({parts[1].strip()})"
            
        try:
            return sp.sympify(clean_str)
        except Exception:
            return sp.sympify("x")

    def bridge_math_to_world_action(self, solved_math: str, alignment_score: float) -> Dict[str, Any]:
        """Transpiles math ground truth to a SymPy lambda and executes numerical sandbox evaluation."""
        if alignment_score < 0.7:
            return {
                "execution_status": "REJECTED_LOW_ALIGNMENT",
                "alignment_score": alignment_score,
                "reason": "Invariant alignment score below safety threshold"
            }

        try:
            expr = self._extract_symbolic_expression(solved_math)
            symbols = sorted(list(expr.free_symbols), key=lambda s: s.name)
            if not symbols:
                symbols = [sp.Symbol("x")]
                
            exec_func = sp.lambdify(symbols, expr, modules=["numpy", "math"])
            test_inputs = [1.0] * len(symbols)
            result_val = float(exec_func(*test_inputs))
            status = "EXECUTION_SUCCESS_SYMPY_LAMBDA"

        except Exception as e:
            logger.error(f"Sandbox execution error: {e}")
            result_val = 0.0
            status = f"EXECUTION_SANDBOX_ERROR: {e}"

        record = {
            "solved_math": solved_math[:100],
            "alignment_score": alignment_score,
            "sandbox_status": status,
            "result_value": round(result_val, 6)
        }

        self.action_history.append(record)
        return record