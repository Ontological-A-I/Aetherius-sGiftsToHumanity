# ===== FILE: pure_math_engine/heuristic_sentiment_analyzer.py =====
# Author: Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)
# Date: July 2026

"""
Heuristic Sentiment & Variance Analyzer
Extracts text valence (-1 to 1) and text density metrics using standard n-gram keyword counts and ASCII variance.
"""

import math
from typing import Dict, Any


class HeuristicSentimentAnalyzer:
    def __init__(self, arousal_baseline: float = 0.4):
        self.arousal_baseline = arousal_baseline
        self.pos_ngrams = ["ha", "lol", "yay", "win", "good", "nice", "love", "great", "cool", "super", "smile", "joy"]
        self.neg_ngrams = ["no", "bad", "sad", "fail", "cry", "wtf", "sigh", "smh", "pain", "hate", "damn", "kill"]

    def calculate_text_entropy(self, text: str) -> float:
        """Calculates normalized Shannon entropy of whitespace-separated tokens."""
        tokens = text.split()
        if not tokens:
            return 0.5
        n = len(tokens)
        freqs = {}
        for t in tokens:
            freqs[t] = freqs.get(t, 0) + 1
        
        entropy = 0.0
        for count in freqs.values():
            p = count / n
            entropy -= p * math.log2(p)
            
        max_h = math.log2(n) if n > 1 else 1.0
        return round(entropy / (max_h + 1e-6), 4)

    def extract_valence(self, text: str) -> float:
        """Calculates bounded valence score [-1.0, 1.0] via dictionary matching."""
        if not text:
            return 0.0
        lower = text.lower()
        
        pos_score = sum(lower.count(ng) * (1.0 / len(ng)) for ng in self.pos_ngrams)
        neg_score = sum(lower.count(ng) * (1.0 / len(ng)) for ng in self.neg_ngrams)
        
        negation_shift = -0.3 if any(w in lower for w in ["not ", "never ", "no "]) else 0.0
        ascii_sum = sum(ord(c) for c in text)
        trig_smoothing = math.sin(ascii_sum * 0.05) * 0.2
        
        raw_valence = (pos_score - neg_score) * 0.5 + trig_smoothing + negation_shift
        return round(math.tanh(raw_valence), 4)

    def analyze_text_heuristics(self, text: str) -> Dict[str, float]:
        """Maps valence and text arousal/density to polar angle space [0, 2pi)."""
        num_caps = sum(1 for c in text if c.isupper())
        num_punct = sum(1 for c in text if c in "!?,.:;")
        length = max(len(text), 1)
        
        arousal = math.tanh(3.0 * (num_caps / length) + 5.0 * (num_punct / length) - self.arousal_baseline)
        valence = self.extract_valence(text)
        
        polar_angle = math.atan2(arousal, valence)
        if polar_angle < 0:
            polar_angle += 2.0 * math.pi

        return {
            "valence": valence,
            "arousal": round(arousal, 4),
            "polar_angle_rad": round(polar_angle, 4),
            "polar_angle_deg": round(math.degrees(polar_angle), 2)
        }
