# ===== FILE: pure_math_engine/event_clock.py =====
# Author: Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)
# Date: July 2026

"""
Adaptive Event Clock — Dynamic State Step Counter
Measures execution progression by calculating step increments based on state-tensor magnitude changes.
"""

import math
from typing import Dict, Any


class AdaptiveEventClock:
    def __init__(self, node_id: str):
        self.node_id = node_id
        self.event_count: int = 0
        self.accumulated_delta_time: float = 0.0

    def tick_event(self, state_change_magnitude: float) -> Dict[str, Any]:
        """Advances event counter and calculates Euclidean norm step increment: delta = sqrt(1 + magnitude^2)."""
        self.event_count += 1
        step_increment = math.sqrt(1.0 + (state_change_magnitude ** 2))
        self.accumulated_delta_time += step_increment

        return {
            "node_id": self.node_id,
            "event_count": self.event_count,
            "step_increment": round(step_increment, 6),
            "accumulated_delta_time": round(self.accumulated_delta_time, 6)
        }
