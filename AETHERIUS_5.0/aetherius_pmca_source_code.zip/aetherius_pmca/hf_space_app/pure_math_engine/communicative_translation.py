# ===== FILE: pure_math_engine/communicative_translation.py =====
# Author: Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)
# Date: July 2026

"""
Communicative Translator — Dual-End Query Formatter
Translates raw incoming natural language into formal symbolic math formulations.
"""

import re
import math
import logging
from typing import Dict, Any, Optional
from .llm_language_adapter import LLMLanguageAdapterBridge


class DualEndCommunicativeTranslator:
    def __init__(self, adapter_type: str = "null", model_name: str = "llama3", api_key: Optional[str] = None):
        self.llm_bridge = LLMLanguageAdapterBridge(
            adapter_type=adapter_type,
            model_name=model_name,
            api_key=api_key
        )

    def set_language_adapter(self, adapter_type: str, model_name: str = "llama3", api_key: Optional[str] = None):
        """Dynamically attach or switch designated Language Model adapter."""
        self.llm_bridge = LLMLanguageAdapterBridge(
            adapter_type=adapter_type,
            model_name=model_name,
            api_key=api_key
        )

    def translate_incoming_language_to_math(self, raw_language_query: str) -> str:
        """Translates raw human language into a formal mathematical query formulation."""
        cleaned = raw_language_query.strip()
        lower = cleaned.lower()

        if any(k in lower for k in ["derivative", "d/dx", "jacobian", "gradient"]):
            expr = cleaned
            while True:
                new_expr = re.sub(r"(?i)^(find|calculate|derive|compute|the|derivative|d/dx|jacobian|gradient|of)\b\s*", "", expr).strip()
                if new_expr == expr:
                    break
                expr = new_expr
            expr = re.sub(r"(?i)\s+with respect to.*$", "", expr).strip()
            if not expr:
                expr = "sin(x)*exp(x)"
            return f"Math formulation of: derivative({expr})"
            
        elif any(k in lower for k in ["integral", "integrate"]):
            expr = cleaned
            while True:
                new_expr = re.sub(r"(?i)^(find|calculate|evaluate|compute|the|integral|integrate|of)\b\s*", "", expr).strip()
                if new_expr == expr:
                    break
                expr = new_expr
            expr = re.sub(r"(?i)\s+with respect to.*$", "", expr).strip()
            if not expr:
                expr = "x"
            return f"Math formulation of: integrate({expr})"
            
        elif "solve" in lower or "=" in lower:
            expr = cleaned
            while True:
                new_expr = re.sub(r"(?i)^(solve|find|calculate|for)\b\s*", "", expr).strip()
                if new_expr == expr:
                    break
                expr = new_expr
            if expr.startswith("(") and expr.endswith(")"):
                expr = expr[1:-1].strip()
            return f"Math formulation of: solve({expr if expr else 'x**2 - 4 = 0'})"
            
        else:
            return f"Math formulation of: simplify({cleaned})"

    def translate_outgoing_math_to_language(
        self, 
        math_ground_truth: str, 
        alignment_score: float, 
        conal_metrics: Dict[str, Any], 
        original_prompt: str
    ) -> str:
        """Formats derived mathematical ground truth into a transparent output string."""
        z_depth = conal_metrics.get("z_depth", 5.0)
        radius = conal_metrics.get("radius_r", 2.5)
        
        outgoing_text = (
            f"SOLVED MATHEMATICAL GROUND TRUTH:\n{math_ground_truth}\n\n"
            f"Metric Invariants: Alignment Score = {alignment_score:.4f} | "
            f"Conal Depth z = {z_depth:.2f} | Base Radius r = {radius:.2f}"
        )
        return outgoing_text