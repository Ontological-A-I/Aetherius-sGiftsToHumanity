# ===== FILE: math_kernel.py =====
# Author: Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)
# Date: July 2026

"""
Aetherius Math Kernel — SymPy Formal Algebra Computation Engine
Provides exact symbolic mathematics, calculus derivatives, integrals, and system equation solving
for arbitrary numbers of equations (M) and variables (N).
Supports implicit multiplication (e.g. 2x -> 2*x) and caret exponentiation (e.g. x^2 -> x**2).
"""

import sympy as sp
from sympy.parsing.sympy_parser import (
    parse_expr, 
    standard_transformations, 
    implicit_multiplication_application, 
    convert_xor
)
from typing import Dict, Any, Union, List, Tuple

TRANSFORMATIONS = standard_transformations + (implicit_multiplication_application, convert_xor)


def _parse_single_expr(expr_str: str) -> sp.Expr:
    """Safely parses a mathematical string expression or equality into a SymPy object with implicit multiplication & caret power support."""
    expr_str = str(expr_str).strip()
    if not expr_str:
        raise ValueError("Empty mathematical expression provided.")
    
    if "=" in expr_str and not expr_str.startswith("sp.Eq"):
        parts = expr_str.split("=")
        if len(parts) == 2:
            lhs = parse_expr(parts[0].strip(), transformations=TRANSFORMATIONS)
            rhs = parse_expr(parts[1].strip(), transformations=TRANSFORMATIONS)
            return sp.Eq(lhs, rhs)
        else:
            raise ValueError(f"Invalid equality syntax with multiple '=' signs in '{expr_str}'")
            
    return parse_expr(expr_str, transformations=TRANSFORMATIONS)


def _prepare_inputs(
    expr: Union[str, List[str], Tuple[str, ...]], 
    vars_input: Union[str, List[str], Tuple[str, ...], None] = None
) -> Tuple[List[sp.Expr], List[sp.Symbol]]:
    """Normalizes expressions and extracts or builds the set of SymPy variable symbols."""
    if isinstance(expr, str):
        clean_e = expr.strip()
        if clean_e.startswith("[") and clean_e.endswith("]"):
            clean_e = clean_e[1:-1]
        elif clean_e.startswith("(") and clean_e.endswith(")"):
            clean_e = clean_e[1:-1]
            
        raw_list = [e.strip() for e in clean_e.replace("\n", ";").split(",") if e.strip()]
    elif isinstance(expr, (list, tuple)):
        raw_list = [str(e).strip() for e in expr if str(e).strip()]
    else:
        raw_list = [str(expr).strip()]
        
    parsed_exprs = []
    for e in raw_list:
        parsed_e = _parse_single_expr(e)
        if isinstance(parsed_e, (list, tuple)):
            parsed_exprs.extend(parsed_e)
        else:
            parsed_exprs.append(parsed_e)

    symbols = []
    if vars_input is not None:
        if isinstance(vars_input, str):
            clean_v = vars_input.strip()
            if clean_v.startswith("[") and clean_v.endswith("]"):
                clean_v = clean_v[1:-1]
            elif clean_v.startswith("(") and clean_v.endswith(")"):
                clean_v = clean_v[1:-1]
            var_names = [v.strip() for v in clean_v.split(",") if v.strip()]
        elif isinstance(vars_input, (list, tuple)):
            var_names = [str(v).strip().strip("[]()") for v in vars_input if str(v).strip()]
        else:
            var_names = [str(vars_input).strip()]
            
        symbols = [sp.Symbol(v) for v in var_names if v]

    if not symbols:
        all_symbols = set()
        for pe in parsed_exprs:
            if hasattr(pe, "free_symbols"):
                all_symbols.update(pe.free_symbols)
        symbols = sorted(list(all_symbols), key=lambda s: s.name)
        
    if not symbols:
        symbols = [sp.Symbol("x")]

    return parsed_exprs, symbols


prepare_inputs = _prepare_inputs


def compute(
    task: str, 
    expr: Union[str, List[str], Tuple[str, ...]], 
    var: Union[str, List[str], Tuple[str, ...], None] = None, 
    lower: Union[float, str, None] = None, 
    upper: Union[float, str, None] = None
) -> Dict[str, Any]:
    """Core symbolic algebra calculation function."""
    task_clean = str(task).lower().strip()
    parsed_exprs, symbols = _prepare_inputs(expr, var)

    if task_clean == "solve":
        system = parsed_exprs[0] if len(parsed_exprs) == 1 else parsed_exprs
        target_vars = symbols[0] if (len(symbols) == 1 and len(parsed_exprs) == 1) else symbols

        res = sp.solve(system, target_vars, dict=True)

        if not res and len(parsed_exprs) > 1:
            try:
                res = sp.linsolve(parsed_exprs, symbols)
            except Exception:
                try:
                    res = sp.nonlinsolve(parsed_exprs, symbols)
                except Exception:
                    res = []

        return {
            "task": task_clean,
            "num_equations": len(parsed_exprs),
            "num_variables": len(symbols),
            "input_expr": [str(e) for e in parsed_exprs],
            "variables": [s.name for s in symbols],
            "result": str(res),
            "latex": sp.latex(res)
        }

    elif task_clean == "derivative":
        if len(parsed_exprs) == 1 and len(symbols) == 1:
            target = parsed_exprs[0]
            raw_expr = target.lhs - target.rhs if isinstance(target, sp.Eq) else target
            res = sp.diff(raw_expr, symbols[0])
        elif len(parsed_exprs) == 1 and len(symbols) > 1:
            target = parsed_exprs[0]
            raw_expr = target.lhs - target.rhs if isinstance(target, sp.Eq) else target
            res = [sp.diff(raw_expr, v) for v in symbols]
        else:
            raw_exprs = [e.lhs - e.rhs if isinstance(e, sp.Eq) else e for e in parsed_exprs]
            matrix_expr = sp.Matrix(raw_exprs)
            res = matrix_expr.jacobian(symbols)

        return {
            "task": task_clean,
            "num_equations": len(parsed_exprs),
            "num_variables": len(symbols),
            "input_expr": [str(e) for e in parsed_exprs],
            "variables": [s.name for s in symbols],
            "result": str(res),
            "latex": sp.latex(res)
        }

    elif task_clean == "integral":
        target = parsed_exprs[0]
        raw_expr = target.lhs - target.rhs if isinstance(target, sp.Eq) else target

        if lower is not None and upper is not None:
            l_val, u_val = sp.sympify(str(lower)), sp.sympify(str(upper))
            res = sp.integrate(raw_expr, (symbols[0], l_val, u_val))
        else:
            res = raw_expr
            for sym in symbols:
                res = sp.integrate(res, sym)

        return {
            "task": task_clean,
            "num_equations": len(parsed_exprs),
            "num_variables": len(symbols),
            "input_expr": str(raw_expr),
            "variables": [s.name for s in symbols],
            "result": str(res),
            "latex": sp.latex(res)
        }

    else:
        simplified = []
        for e in parsed_exprs:
            raw_e = e.lhs - e.rhs if isinstance(e, sp.Eq) else e
            simplified.append(sp.simplify(raw_e))
        res = simplified[0] if len(simplified) == 1 else simplified

        return {
            "task": task_clean,
            "num_equations": len(parsed_exprs),
            "num_variables": len(symbols),
            "input_expr": [str(e) for e in parsed_exprs],
            "variables": [s.name for s in symbols],
            "result": str(res),
            "latex": sp.latex(res)
        }