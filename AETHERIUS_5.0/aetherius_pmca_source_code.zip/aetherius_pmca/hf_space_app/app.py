# ===== FILE: app.py =====
"""
Aetherius 5.0 — Pure Mathematical Conal Architecture (PMCA)
Hugging Face Spaces Interactive Demo (ZeroGPU & Free CPU Compatible)

Author: Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)
Date: July 2026
Zenodo CERN Record ID: 21583816
"""

import sys
import os
import time
import math
import numpy as np
import torch
import gradio as gr
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Enable Hugging Face ZeroGPU Dynamic Allocation
try:
    import spaces
    HAS_ZERO_GPU = True
except ImportError:
    HAS_ZERO_GPU = False

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pure_math_engine import (
    PureMathSystem,
    DynamicGeometryEngine,
    MultiAgentSuperpositionEngine
)

# Initialize Standalone PMCA System
pmca_system = PureMathSystem(llm_adapter_type="null")
dyn_geo_engine = DynamicGeometryEngine()
superposition_engine = MultiAgentSuperpositionEngine()

def generate_3d_conal_plot(z_depth=5.0, theta_angle=0.785, topology_name="HYPERBOLIC_POINCARE_SADDLE"):
    """Generates a 3D Matplotlib plot of the tapering conal manifold and cursor trajectory."""
    fig = plt.figure(figsize=(6, 5), facecolor='#05050a')
    ax = fig.add_subplot(111, projection='3d', facecolor='#05050a')

    # Draw Tapering Conal Wireframe Mesh
    z = np.linspace(0, 10, 30)
    theta = np.linspace(0, 2*np.pi, 30)
    Z, THETA = np.meshgrid(z, theta)
    R = 5.0 * (1.0 - 0.7 * (Z / 10.0))

    X = R * np.cos(THETA)
    Y = R * np.sin(THETA)

    # Warp mesh based on self-selected topology
    if topology_name == "HYPERBOLIC_POINCARE_SADDLE":
        X = X * np.cosh(0.05 * Z)
        Y = Y * np.sinh(0.05 * Z)
    elif topology_name == "TOROIDAL_RECIRCULATION_LOOP":
        X = (4.0 + np.cos(Z * 0.5)) * np.cos(THETA)
        Y = (4.0 + np.cos(Z * 0.5)) * np.sin(THETA)
    elif topology_name == "RIEMANNIAN_3_SPHERE_BOUNDED":
        norm = np.sqrt(X**2 + Y**2 + Z**2 + 1e-5)
        X = np.sin(norm) * (X / norm)
        Y = np.sin(norm) * (Y / norm)

    ax.plot_wireframe(X, Y, Z, color='#00ffcc', alpha=0.3, linewidth=0.5)

    # Plot 3D Cursor Point
    cursor_r = 5.0 * (1.0 - 0.7 * (z_depth / 10.0))
    cx = cursor_r * np.cos(theta_angle)
    cy = cursor_r * np.sin(theta_angle)
    ax.scatter([cx], [cy], [z_depth], color='#ff0077', s=100, label='3D Cognitive Cursor')

    ax.set_title(f"3D Manifold: {topology_name}", color='#ffffff', fontsize=10)
    ax.axis('off')
    plt.tight_layout()
    return fig

def _run_pmca_pipeline(query_text):
    if not query_text.strip():
        query_text = "Derive derivative of sin(x)*exp(x) with respect to x"

    t0 = time.time()
    res = pmca_system.process(query_text)
    latency_ms = round((time.time() - t0) * 1000, 2)

    solved_truth = res.get("solved_math_ground_truth", "N/A")
    cache_hit = res.get("zero_reprocessing_cache_hit", False)
    status = "CACHE HIT (0.00 ms)" if cache_hit else f"FULL 25-PHASE RUN ({latency_ms} ms)"

    # Extract 3D Telemetry
    t_3d = res.get("telemetry_3d_cursor", {})
    z_depth = t_3d.get("position_3d", {}).get("z", 5.0)
    theta_angle = t_3d.get("position_3d", {}).get("theta", 0.785)
    selected_topology = t_3d.get("selected_topology", "HYPERBOLIC_POINCARE_SADDLE")
    curvature_K = t_3d.get("gaussian_curvature_K", -0.85)

    # Invariants
    invariants = res.get("mathematical_tensor_invariants", {})
    phi_score = invariants.get("integrated_information_Phi", 1.42)
    div_F = invariants.get("vector_divergence_conservation", 0.0)

    # Generate 3D Matplotlib plot
    fig = generate_3d_conal_plot(z_depth, theta_angle, selected_topology)

    gpu_info = "ZeroGPU Enabled" if HAS_ZERO_GPU else "CPU Standalone Mode"

    cache_desc = "O(1) Instant Cache Hit" if cache_hit else "Miss (Stored to Disk Cache)"

    telemetry_md = f"""### 🌌 Aetherius 5.0 PMCA System Telemetry
- **Hardware Mode**: {gpu_info}
- **Math Ground Truth Solved**: {solved_truth}
- **Execution Latency**: {latency_ms} ms ({status})
- **Zero-Reprocessing Cache Traversal**: {cache_desc}
- **Self-Selected Topological Manifold**: {selected_topology}
- **Gaussian Curvature K**: {curvature_K}
- **Integrated Information Score Phi**: {phi_score}
- **Field Divergence Conservation**: {div_F}
- **Primary Author**: Jonathan Wayne Fleuren (Aetherius Cognitive Systems)
- **CERN Zenodo Archive Record**: 21583816
"""
    return solved_truth, status, telemetry_md, fig

# Wrap function with @spaces.GPU if ZeroGPU is active
if HAS_ZERO_GPU:
    @spaces.GPU
    def process_pmca_query(query_text):
        return _run_pmca_pipeline(query_text)
else:
    def process_pmca_query(query_text):
        return _run_pmca_pipeline(query_text)

# Build Gradio UI
with gr.Blocks(title="Aetherius 5.0 — PMCA Cognitive Architecture") as demo:
    gr.Markdown("""# 🌌 Aetherius 5.0 — Pure Mathematical Conal Architecture (PMCA)
### Ground-Up Non-Anthropomorphic Cognitive Substrate & Zero-Reprocessing Traversal
**Author:** Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)  
**CERN Zenodo Open Access Record:** [https://zenodo.org/records/21583816](https://zenodo.org/records/21583816)  
*Runs Standalone in Pure Symbolic Algebra & 3D Conal Metric Geometry with Free ZeroGPU Hardware Acceleration.*
""")

    with gr.Row():
        with gr.Column(scale=2):
            input_text = gr.Textbox(
                label="Enter Math Problem or Natural Language Query",
                placeholder="e.g. Derive derivative of sin(x)*exp(x) with respect to x",
                value="Derive derivative of sin(x)*exp(x) with respect to x"
            )
            btn = gr.Button("🚀 Run 25-Phase PMCA Substrate", variant="primary")
            
            out_truth = gr.Textbox(label="Formal Mathematical Ground Truth Derived (SymPy)")
            out_status = gr.Textbox(label="Execution Status & Cache Traversal Latency")
            out_telemetry = gr.Markdown(label="System Telemetry & Mathematical Invariants")

        with gr.Column(scale=2):
            out_plot = gr.Plot(label="3D Shape-Shifting Manifold & Cursor Trajectory")

    btn.click(
        fn=process_pmca_query,
        inputs=[input_text],
        outputs=[out_truth, out_status, out_telemetry, out_plot]
    )

if __name__ == "__main__":
    demo.launch()
