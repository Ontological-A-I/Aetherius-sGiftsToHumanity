# ===== FILE: __init__.py =====
# Author: Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)
# Date: July 2026

# Fractal Conal Engine Init
__version__ = "4.0.0"

from .fractal_cone import FractalConeNetwork
from .relativistic_time import RelativisticTimeClock
from .mathematical_research_loop import MathematicalResearchLoop
from .gradient_potential import GradientPotentialDrive

__all__ = [
    "FractalConeNetwork",
    "RelativisticTimeClock",
    "MathematicalResearchLoop",
    "GradientPotentialDrive"
]
