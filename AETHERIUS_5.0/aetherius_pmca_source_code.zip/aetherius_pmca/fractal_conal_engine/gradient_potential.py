# ===== FILE: fractal_conal_engine/gradient_potential.py =====
# Author: Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)
# Date: July 2026
"""
Gradient Potential Drive — Potential Energy & Acceleration Field Substrate
Calculates the analytical potential field V(z) and driving acceleration force F_drive(z) = -grad(V)
forcing state vector tensors deeper down the conal depth z into singular ground truth solutions.
"""

import math
import logging
from typing import Dict, Any

logger = logging.getLogger("FractalConal.GradientPotential")

class GradientPotentialDrive:
    def __init__(
        self,
        z_max: float = 10.0,
        k_focal: float = 5.0,
        gamma_entropy: float = 2.0,
        lambda_decay: float = 0.5,
        epsilon: float = 0.1
    ):
        self.z_max = z_max
        self.k_focal = k_focal
        self.gamma_entropy = gamma_entropy
        self.lambda_decay = lambda_decay
        self.epsilon = epsilon

    def compute_potential_energy_V(self, z: float, tensor_entropy: float) -> float:
        """
        Computes Potential Energy V(z) = V_attraction(z) + V_entropy(z).
        """
        z_bounded = min(self.z_max - self.epsilon, max(0.0, z))
        denom = (self.z_max - z_bounded + self.epsilon) ** 2

        v_attraction = -self.k_focal / denom
        v_entropy = self.gamma_entropy * tensor_entropy * math.exp(-self.lambda_decay * z_bounded)

        return round(v_attraction + v_entropy, 6)

    def compute_gradient_force(self, z: float, tensor_entropy: float) -> Dict[str, Any]:
        """
        Computes driving force vector F_drive(z) = -grad(V) along the z-axis.
        F_drive(z) = [2 * k_focal / (Z_max - z + eps)^3 + lambda * gamma * s_entropy * exp(-lambda * z)] * z_hat
        """
        z_bounded = min(self.z_max - self.epsilon, max(0.0, z))
        denom_cube = (self.z_max - z_bounded + self.epsilon) ** 3

        f_focal = (2.0 * self.k_focal) / denom_cube
        f_entropy = self.lambda_decay * self.gamma_entropy * tensor_entropy * math.exp(-self.lambda_decay * z_bounded)

        net_force_z = f_focal + f_entropy
        v_potential = self.compute_potential_energy_V(z_bounded, tensor_entropy)

        return {
            "z_depth": z_bounded,
            "potential_energy_V": v_potential,
            "focal_pull_component": round(f_focal, 6),
            "entropy_push_component": round(f_entropy, 6),
            "net_gradient_drive_force": round(net_force_z, 6),
            "acceleration_direction": "TOWARD_CONAL_APEX_GROUND_TRUTH"
        }