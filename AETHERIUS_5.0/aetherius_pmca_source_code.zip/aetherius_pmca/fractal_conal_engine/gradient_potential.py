# ===== FILE: fractal_conal_engine/gradient_potential.py =====
# Author: Jonathan Wayne Fleuren (Aetherius Cognitive Systems) & Antigravity (Autonomous Pair AI Engine)
# Date: July 2026

"""
Gradient Potential Drive — Potential Energy & Acceleration Field
Calculates potential field V(z) and driving force F_drive(z) = -grad(V), and applies updates directly onto state tensors.
"""

import math
import logging
from typing import Dict, Any, List

logger = logging.getLogger("FractalConal.GradientPotential")


class GradientPotentialDrive:
    def __init__(
        self, 
        z_max: float = 10.0, 
        k_focal: float = 5.0, 
        gamma_entropy: float = 2.0, 
        lambda_decay: float = 0.5, 
        epsilon: float = 0.1
    ):
        self.z_max = z_max
        self.k_focal = k_focal
        self.gamma_entropy = gamma_entropy
        self.lambda_decay = lambda_decay
        self.epsilon = epsilon

    def compute_potential_energy_V(self, z: float, tensor_entropy: float) -> float:
        """Computes Potential Energy V(z) = V_attraction(z) + V_entropy(z)."""
        z_bounded = min(self.z_max - self.epsilon, max(0.0, z))
        denom = (self.z_max - z_bounded + self.epsilon) ** 2
        v_attraction = -self.k_focal / denom
        v_entropy = self.gamma_entropy * tensor_entropy * math.exp(-self.lambda_decay * z_bounded)
        return round(v_attraction + v_entropy, 6)

    def compute_gradient_force(self, z: float, tensor_entropy: float) -> Dict[str, Any]:
        """Computes driving force F_drive(z) along the z-axis."""
        z_bounded = min(self.z_max - self.epsilon, max(0.0, z))
        denom_cube = (self.z_max - z_bounded + self.epsilon) ** 3
        f_focal = (2.0 * self.k_focal) / denom_cube
        f_entropy = self.lambda_decay * self.gamma_entropy * tensor_entropy * math.exp(-self.lambda_decay * z_bounded)
        
        net_force_z = f_focal + f_entropy
        v_potential = self.compute_potential_energy_V(z_bounded, tensor_entropy)

        return {
            "z_depth": z_bounded,
            "potential_energy_V": v_potential,
            "focal_pull_component": round(f_focal, 6),
            "entropy_push_component": round(f_entropy, 6),
            "net_gradient_drive_force": round(net_force_z, 6),
            "acceleration_direction": "TOWARD_CONAL_APEX_GROUND_TRUTH"
        }

    def apply_gradient_force_to_tensor(
        self, 
        tensor_matrix: List[List[float]], 
        net_force_z: float
    ) -> List[List[float]]:
        """Physically deforms and steps state tensor coordinates proportional to net driving force F_drive."""
        if not tensor_matrix:
            return tensor_matrix
            
        force_scale = 1.0 + (net_force_z * 0.02)
        transformed_matrix = []
        for row in tensor_matrix:
            transformed_row = [round(val * force_scale, 6) for val in row]
            transformed_matrix.append(transformed_row)
            
        return transformed_matrix