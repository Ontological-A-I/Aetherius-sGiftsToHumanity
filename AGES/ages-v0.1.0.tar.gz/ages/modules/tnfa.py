"""
Transparent Network Flow Analysis (TNFA)
Monitors network metadata to detect malicious connections and patterns
"""

import time
import threading
import socket
from typing import Dict, List, Any, Set, Tuple
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta

from core.base_module import BaseModule
from core.engine import ThreatEvent, ThreatLevel


@dataclass
class NetworkFlow:
    """Represents a network flow/connection"""
    src_ip: str
    src_port: int
    dst_ip: str
    dst_port: int
    protocol: str
    bytes_sent: int
    bytes_recv: int
    start_time: datetime
    last_seen: datetime
    connection_count: int = 1


class TNFA(BaseModule):
    """
    Transparent Network Flow Analysis Module
    
    Monitors network connections and traffic patterns to detect:
    - Suspicious outbound connections
    - Port scanning attempts
    - Data exfiltration patterns
    - C2 communication patterns
    """
    
    def __init__(self, engine: Any, config: Dict[str, Any]):
        super().__init__(engine, config)
        
        # Configuration
        self.monitor_interval = config.get('monitor_interval', 5.0)
        self.suspicious_port_threshold = config.get('suspicious_port_threshold', 10)
        self.data_exfil_threshold = config.get('data_exfil_threshold_mb', 100) * 1024 * 1024
        
        # Network flow tracking
        self.active_flows: Dict[Tuple, NetworkFlow] = {}
        self.flow_history: deque = deque(maxlen=1000)
        
        # Suspicious patterns
        self.port_scan_tracker: Dict[str, Set[int]] = defaultdict(set)
        self.connection_frequency: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
        
        # Known malicious indicators (would be populated from threat intel)
        self.blacklisted_ips: Set[str] = set()
        self.suspicious_ports: Set[int] = {
            4444, 5555, 6666, 7777, 8888, 9999,  # Common backdoor ports
            31337, 12345, 54321,  # Classic trojan ports
            1337, 6667, 6697,  # IRC (potential C2)
        }
        
        # Statistics
        self.total_flows = 0
        self.suspicious_flows = 0
        self.blocked_connections = 0
        
        self.logger.info("TNFA module initialized")
    
    def start(self) -> None:
        """Start network flow monitoring"""
        if not self.is_enabled():
            self.logger.info("TNFA module disabled in configuration")
            return
        
        self.running = True
        self.logger.info("TNFA module started")
        
        # Start monitoring thread
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            daemon=True
        )
        self.monitor_thread.start()
        
        # Start cleanup thread
        self.cleanup_thread = threading.Thread(
            target=self._cleanup_loop,
            daemon=True
        )
        self.cleanup_thread.start()
    
    def stop(self) -> None:
        """Stop network flow monitoring"""
        self.running = False
        self.logger.info("TNFA module stopped")
    
    def _monitoring_loop(self) -> None:
        """Main monitoring loop"""
        while self.running:
            try:
                # Monitor active connections
                self._monitor_connections()
                
                # Analyze patterns
                self._analyze_port_scanning()
                self._analyze_data_exfiltration()
                self._analyze_c2_patterns()
                
                time.sleep(self.monitor_interval)
                
            except Exception as e:
                self.logger.error(f"Error in TNFA monitoring loop: {e}", exc_info=True)
    
    def _monitor_connections(self) -> None:
        """Monitor active network connections"""
        try:
            import psutil
            
            connections = psutil.net_connections(kind='inet')
            
            for conn in connections:
                if conn.status != 'ESTABLISHED':
                    continue
                
                # Skip local connections
                if conn.laddr and conn.raddr:
                    if conn.raddr.ip.startswith('127.') or conn.raddr.ip.startswith('::1'):
                        continue
                    
                    # Create flow identifier
                    flow_key = (
                        conn.laddr.ip,
                        conn.laddr.port,
                        conn.raddr.ip,
                        conn.raddr.port
                    )
                    
                    # Update or create flow
                    if flow_key in self.active_flows:
                        flow = self.active_flows[flow_key]
                        flow.last_seen = datetime.now()
                        flow.connection_count += 1
                    else:
                        flow = NetworkFlow(
                            src_ip=conn.laddr.ip,
                            src_port=conn.laddr.port,
                            dst_ip=conn.raddr.ip,
                            dst_port=conn.raddr.port,
                            protocol='TCP' if conn.type == socket.SOCK_STREAM else 'UDP',
                            bytes_sent=0,
                            bytes_recv=0,
                            start_time=datetime.now(),
                            last_seen=datetime.now()
                        )
                        self.active_flows[flow_key] = flow
                        self.total_flows += 1
                    
                    # Check for immediate threats
                    self._check_flow_threats(flow)
                    
                    # Track connection patterns
                    self._track_connection_patterns(flow)
                    
        except ImportError:
            self.logger.warning("psutil not available - network monitoring limited")
        except Exception as e:
            self.logger.error(f"Error monitoring connections: {e}")
    
    def _check_flow_threats(self, flow: NetworkFlow) -> None:
        """Check individual flow for immediate threats"""
        
        # Check against blacklisted IPs
        if flow.dst_ip in self.blacklisted_ips:
            self._report_threat(
                flow,
                ThreatLevel.CONFIRMED_MALICIOUS,
                0.98,
                f"Connection to blacklisted IP: {flow.dst_ip}"
            )
            return
        
        # Check for suspicious ports
        if flow.dst_port in self.suspicious_ports:
            self._report_threat(
                flow,
                ThreatLevel.SUSPICIOUS,
                0.65,
                f"Connection to suspicious port: {flow.dst_port}"
            )
        
        # Check for non-standard high ports (potential backdoor)
        if flow.dst_port > 49152 and flow.connection_count > 10:
            self._report_threat(
                flow,
                ThreatLevel.SUSPICIOUS,
                0.55,
                f"Repeated connections to high port: {flow.dst_port}"
            )
    
    def _track_connection_patterns(self, flow: NetworkFlow) -> None:
        """Track connection patterns for later analysis"""
        
        # Track ports accessed from this source
        self.port_scan_tracker[flow.src_ip].add(flow.dst_port)
        
        # Track connection frequency
        self.connection_frequency[flow.dst_ip].append(datetime.now())
    
    def _analyze_port_scanning(self) -> None:
        """Detect port scanning behavior"""
        for src_ip, ports in self.port_scan_tracker.items():
            if len(ports) > self.suspicious_port_threshold:
                self.suspicious_flows += 1
                
                threat = ThreatEvent(
                    timestamp=datetime.now(),
                    source="TNFA",
                    threat_level=ThreatLevel.LIKELY_MALICIOUS,
                    confidence=min(0.7 + (len(ports) / 100), 0.95),
                    description=f"Port scanning detected from {src_ip} - {len(ports)} ports accessed",
                    metadata={
                        'src_ip': src_ip,
                        'ports_scanned': len(ports),
                        'target': src_ip
                    }
                )
                
                self.report_threat(threat)
                
                # Clear tracker after reporting
                self.port_scan_tracker[src_ip].clear()
    
    def _analyze_data_exfiltration(self) -> None:
        """Detect potential data exfiltration patterns"""
        for flow_key, flow in list(self.active_flows.items()):
            # Check for large outbound data transfers
            if flow.bytes_sent > self.data_exfil_threshold:
                duration = (flow.last_seen - flow.start_time).total_seconds()
                
                if duration < 300:  # Large transfer in under 5 minutes
                    self._report_threat(
                        flow,
                        ThreatLevel.LIKELY_MALICIOUS,
                        0.75,
                        f"Potential data exfiltration to {flow.dst_ip} - {flow.bytes_sent / 1024 / 1024:.2f} MB sent"
                    )
    
    def _analyze_c2_patterns(self) -> None:
        """Detect Command & Control communication patterns"""
        for dst_ip, timestamps in self.connection_frequency.items():
            if len(timestamps) < 10:
                continue
            
            # Check for regular beaconing pattern
            if len(timestamps) >= 5:
                intervals = []
                for i in range(1, len(timestamps)):
                    interval = (timestamps[i] - timestamps[i-1]).total_seconds()
                    intervals.append(interval)
                
                # If intervals are very regular, might be C2 beaconing
                if intervals:
                    avg_interval = sum(intervals) / len(intervals)
                    variance = sum((x - avg_interval) ** 2 for x in intervals) / len(intervals)
                    
                    # Low variance indicates regular beaconing
                    if variance < 10 and avg_interval < 60:  # Regular connections under 1 minute
                        threat = ThreatEvent(
                            timestamp=datetime.now(),
                            source="TNFA",
                            threat_level=ThreatLevel.SUSPICIOUS,
                            confidence=0.70,
                            description=f"Potential C2 beaconing to {dst_ip} - regular {avg_interval:.1f}s intervals",
                            metadata={
                                'dst_ip': dst_ip,
                                'avg_interval': avg_interval,
                                'connection_count': len(timestamps),
                                'target': dst_ip
                            }
                        )
                        
                        self.report_threat(threat)
    
    def _report_threat(self, flow: NetworkFlow, level: ThreatLevel, confidence: float, description: str) -> None:
        """Report a network-based threat"""
        self.suspicious_flows += 1
        
        threat = ThreatEvent(
            timestamp=datetime.now(),
            source="TNFA",
            threat_level=level,
            confidence=confidence,
            description=description,
            metadata={
                'src_ip': flow.src_ip,
                'src_port': flow.src_port,
                'dst_ip': flow.dst_ip,
                'dst_port': flow.dst_port,
                'protocol': flow.protocol,
                'target': f"{flow.dst_ip}:{flow.dst_port}"
            }
        )
        
        self.report_threat(threat)
        
        # If high confidence, block the connection
        if confidence >= 0.90:
            self._block_connection(flow)
    
    def _block_connection(self, flow: NetworkFlow) -> None:
        """Block a malicious connection"""
        self.blocked_connections += 1
        self.logger.warning(f"Blocking connection to {flow.dst_ip}:{flow.dst_port}")
        
        # In production, this would add firewall rules
        # For now, just remove from active flows
        flow_key = (flow.src_ip, flow.src_port, flow.dst_ip, flow.dst_port)
        if flow_key in self.active_flows:
            del self.active_flows[flow_key]
    
    def _cleanup_loop(self) -> None:
        """Clean up stale flows"""
        while self.running:
            try:
                now = datetime.now()
                stale_threshold = timedelta(minutes=5)
                
                # Remove stale flows
                stale_keys = [
                    key for key, flow in self.active_flows.items()
                    if now - flow.last_seen > stale_threshold
                ]
                
                for key in stale_keys:
                    flow = self.active_flows.pop(key)
                    self.flow_history.append(flow)
                
                if stale_keys:
                    self.logger.debug(f"Cleaned up {len(stale_keys)} stale flows")
                
                time.sleep(60)  # Cleanup every minute
                
            except Exception as e:
                self.logger.error(f"Error in cleanup loop: {e}")
    
    def add_blacklisted_ip(self, ip: str) -> None:
        """Add an IP to the blacklist"""
        self.blacklisted_ips.add(ip)
        self.logger.info(f"Added {ip} to blacklist")
    
    def get_status(self) -> Dict[str, Any]:
        """Return current module status"""
        return {
            'enabled': self.is_enabled(),
            'running': self.running,
            'total_flows': self.total_flows,
            'active_flows': len(self.active_flows),
            'suspicious_flows': self.suspicious_flows,
            'blocked_connections': self.blocked_connections,
            'blacklisted_ips': len(self.blacklisted_ips)
        }
