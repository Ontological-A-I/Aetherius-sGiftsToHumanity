"""
Metabolic Budget Controller (MBC)
Ensures AGES processes yield to user workloads and prevents resource parasitism
"""

import time
import threading
from typing import Dict, List, Any, Callable
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

from core.base_module import BaseModule


class Priority(Enum):
    """Task priority levels"""
    CRITICAL = 0  # User-critical tasks
    HIGH = 1      # Important AGES tasks
    NORMAL = 2    # Standard AGES operations
    LOW = 3       # Background learning/optimization
    IDLE = 4      # Only when system is idle


@dataclass
class Task:
    """Represents a scheduled task"""
    task_id: str
    priority: Priority
    cpu_cost: float  # Estimated CPU usage (0-1)
    memory_cost: float  # Estimated memory usage in MB
    callback: Callable
    scheduled_time: datetime
    deadline: datetime
    executed: bool = False


class MBC(BaseModule):
    """
    Metabolic Budget Controller Module
    
    The guardian of system resources - ensures AGES never becomes a burden.
    Implements the principle: Survival (of host) > Growth (of AGES)
    """
    
    def __init__(self, engine: Any, config: Dict[str, Any]):
        super().__init__(engine, config)
        
        # Configuration - Resource thresholds
        self.cpu_threshold = config.get('cpu_threshold', 70.0)  # Percent
        self.memory_threshold = config.get('memory_threshold', 80.0)  # Percent
        self.disk_io_threshold = config.get('disk_io_threshold', 80.0)  # Percent
        
        # Adaptive throttling
        self.throttle_factor = 1.0  # 1.0 = no throttle, 0.0 = full throttle
        self.min_throttle = config.get('min_throttle', 0.1)
        
        # Task queue
        self.task_queue: List[Task] = []
        self.task_lock = threading.Lock()
        
        # Resource monitoring
        self.current_cpu = 0.0
        self.current_memory = 0.0
        self.current_disk_io = 0.0
        
        # Statistics
        self.tasks_executed = 0
        self.tasks_deferred = 0
        self.total_throttle_time = 0.0
        
        self.logger.info("MBC module initialized - metabolic governance active")
    
    def start(self) -> None:
        """Start the MBC controller"""
        if not self.is_enabled():
            self.logger.info("MBC module disabled in configuration")
            return
        
        self.running = True
        self.logger.info("MBC module started")
        
        # Start monitoring thread
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            daemon=True
        )
        self.monitor_thread.start()
        
        # Start scheduler thread
        self.scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True
        )
        self.scheduler_thread.start()
    
    def stop(self) -> None:
        """Stop the MBC controller"""
        self.running = False
        self.logger.info("MBC module stopped")
    
    def _monitoring_loop(self) -> None:
        """Monitor system resources continuously"""
        while self.running:
            try:
                self._update_resource_metrics()
                self._adjust_throttle()
                
                time.sleep(self.config.get('monitor_interval', 2.0))
                
            except Exception as e:
                self.logger.error(f"Error in MBC monitoring loop: {e}", exc_info=True)
    
    def _update_resource_metrics(self) -> None:
        """Update current resource usage metrics"""
        try:
            import psutil
            
            self.current_cpu = psutil.cpu_percent(interval=0.1)
            self.current_memory = psutil.virtual_memory().percent
            
            # Disk I/O (simplified)
            disk_io = psutil.disk_io_counters()
            self.current_disk_io = min((disk_io.read_bytes + disk_io.write_bytes) / (1024**3), 100)
            
        except ImportError:
            # Fallback if psutil not available
            self.current_cpu = 0.0
            self.current_memory = 0.0
            self.current_disk_io = 0.0
    
    def _adjust_throttle(self) -> None:
        """Dynamically adjust throttle based on system load"""
        # Calculate resource pressure
        cpu_pressure = max(0, self.current_cpu - self.cpu_threshold) / (100 - self.cpu_threshold)
        memory_pressure = max(0, self.current_memory - self.memory_threshold) / (100 - self.memory_threshold)
        disk_pressure = max(0, self.current_disk_io - self.disk_io_threshold) / (100 - self.disk_io_threshold)
        
        # Overall pressure (max of all pressures)
        overall_pressure = max(cpu_pressure, memory_pressure, disk_pressure)
        
        # Adjust throttle factor (inverse of pressure)
        old_throttle = self.throttle_factor
        self.throttle_factor = max(1.0 - overall_pressure, self.min_throttle)
        
        # Log significant changes
        if abs(old_throttle - self.throttle_factor) > 0.2:
            self.logger.info(
                f"Throttle adjusted: {old_throttle:.2f} -> {self.throttle_factor:.2f} "
                f"(CPU: {self.current_cpu:.1f}%, Mem: {self.current_memory:.1f}%)"
            )
    
    def schedule_task(self, task_id: str, priority: Priority, 
                     cpu_cost: float, memory_cost: float,
                     callback: Callable, deadline: datetime = None) -> bool:
        """Schedule a task with resource awareness"""
        
        if deadline is None:
            deadline = datetime.now() + timedelta(hours=1)
        
        task = Task(
            task_id=task_id,
            priority=priority,
            cpu_cost=cpu_cost,
            memory_cost=memory_cost,
            callback=callback,
            scheduled_time=datetime.now(),
            deadline=deadline
        )
        
        with self.task_lock:
            self.task_queue.append(task)
            # Sort by priority
            self.task_queue.sort(key=lambda t: (t.priority.value, t.scheduled_time))
        
        self.logger.debug(f"Scheduled task {task_id} with priority {priority.name}")
        return True
    
    def _scheduler_loop(self) -> None:
        """Execute scheduled tasks based on resource availability"""
        while self.running:
            try:
                self._execute_pending_tasks()
                
                time.sleep(self.config.get('scheduler_interval', 5.0))
                
            except Exception as e:
                self.logger.error(f"Error in MBC scheduler loop: {e}", exc_info=True)
    
    def _execute_pending_tasks(self) -> None:
        """Execute tasks if resources are available"""
        with self.task_lock:
            if not self.task_queue:
                return
            
            # Get next task
            task = self.task_queue[0]
            
            # Check if we have resources
            if not self._can_execute_task(task):
                # Defer task
                self.tasks_deferred += 1
                
                # If past deadline and low priority, remove
                if datetime.now() > task.deadline and task.priority.value >= Priority.NORMAL.value:
                    self.task_queue.pop(0)
                    self.logger.debug(f"Dropped task {task.task_id} - deadline exceeded")
                
                return
            
            # Execute task
            self.task_queue.pop(0)
        
        self._execute_task(task)
    
    def _can_execute_task(self, task: Task) -> bool:
        """Check if we have resources to execute a task"""
        # Critical tasks always execute
        if task.priority == Priority.CRITICAL:
            return True
        
        # Check CPU availability
        estimated_cpu = self.current_cpu + (task.cpu_cost * 100)
        if estimated_cpu > self.cpu_threshold:
            return False
        
        # Check memory availability
        try:
            import psutil
            available_memory = psutil.virtual_memory().available / (1024**2)  # MB
            if task.memory_cost > available_memory * 0.5:  # Don't use more than 50% of available
                return False
        except ImportError:
            pass
        
        # Check throttle factor
        if task.priority.value >= Priority.NORMAL.value:
            if self.throttle_factor < 0.5:
                return False
        
        return True
    
    def _execute_task(self, task: Task) -> None:
        """Execute a task"""
        try:
            start_time = time.time()
            
            self.logger.debug(f"Executing task {task.task_id}")
            
            # Apply throttle delay for non-critical tasks
            if task.priority != Priority.CRITICAL:
                throttle_delay = (1.0 - self.throttle_factor) * 2.0  # Up to 2 seconds
                if throttle_delay > 0.1:
                    time.sleep(throttle_delay)
                    self.total_throttle_time += throttle_delay
            
            # Execute callback
            task.callback()
            task.executed = True
            self.tasks_executed += 1
            
            execution_time = time.time() - start_time
            self.logger.debug(f"Task {task.task_id} completed in {execution_time:.2f}s")
            
        except Exception as e:
            self.logger.error(f"Error executing task {task.task_id}: {e}", exc_info=True)
    
    def get_resource_budget(self) -> Dict[str, float]:
        """Get current resource budget available for AGES operations"""
        try:
            import psutil
            
            cpu_available = max(0, self.cpu_threshold - self.current_cpu)
            memory_available = psutil.virtual_memory().available / (1024**2)  # MB
            
            return {
                'cpu_percent_available': cpu_available,
                'memory_mb_available': memory_available,
                'throttle_factor': self.throttle_factor,
                'can_run_background_tasks': self.throttle_factor > 0.5
            }
        except ImportError:
            return {
                'cpu_percent_available': 30.0,
                'memory_mb_available': 1000.0,
                'throttle_factor': self.throttle_factor,
                'can_run_background_tasks': True
            }
    
    def request_permission(self, operation: str, priority: Priority, 
                          estimated_cpu: float, estimated_memory: float) -> bool:
        """Request permission to perform an operation"""
        
        # Critical operations always allowed
        if priority == Priority.CRITICAL:
            return True
        
        # Check resource availability
        if self.current_cpu + (estimated_cpu * 100) > self.cpu_threshold:
            self.logger.debug(f"Permission denied for {operation}: CPU threshold exceeded")
            return False
        
        # Check throttle
        if priority.value >= Priority.NORMAL.value and self.throttle_factor < 0.3:
            self.logger.debug(f"Permission denied for {operation}: System under heavy load")
            return False
        
        return True
    
    def get_status(self) -> Dict[str, Any]:
        """Return current module status"""
        return {
            'enabled': self.is_enabled(),
            'running': self.running,
            'current_cpu': self.current_cpu,
            'current_memory': self.current_memory,
            'throttle_factor': self.throttle_factor,
            'pending_tasks': len(self.task_queue),
            'tasks_executed': self.tasks_executed,
            'tasks_deferred': self.tasks_deferred,
            'total_throttle_time_seconds': self.total_throttle_time
        }


# Import for timedelta
from datetime import timedelta
