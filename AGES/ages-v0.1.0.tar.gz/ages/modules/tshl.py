"""
Temporal Symbolic Half-Life (TSHL)
Implements confidence decay and rule aging to prevent historical overfitting
"""

import time
import threading
import math
from typing import Dict, List, Any
from datetime import datetime, timedelta
from dataclasses import dataclass

from core.base_module import BaseModule


@dataclass
class RuleMetadata:
    """Metadata for rule aging and decay"""
    rule_id: str
    initial_confidence: float
    current_confidence: float
    last_confirmed: datetime
    last_contradicted: datetime
    confirmation_count: int
    contradiction_count: int
    soft_contradiction_count: int
    age_days: float
    decay_rate: float
    is_quarantined: bool = False


class TSHL(BaseModule):
    """
    Temporal Symbolic Half-Life Module
    
    Implements entropy pressure on rules, causing confidence to decay over time
    without reinforcement. Prevents "ancient truth poisoning" and keeps the
    system agile and adaptive.
    """
    
    def __init__(self, engine: Any, config: Dict[str, Any]):
        super().__init__(engine, config)
        
        # Configuration
        self.base_half_life_days = config.get('base_half_life_days', 30.0)
        self.soft_contradiction_threshold = config.get('soft_contradiction_threshold', 5)
        self.hard_contradiction_threshold = config.get('hard_contradiction_threshold', 3)
        self.min_confidence = config.get('min_confidence', 0.3)
        self.confirmation_boost = config.get('confirmation_boost', 0.05)
        self.contradiction_penalty = config.get('contradiction_penalty', 0.15)
        
        # Rule tracking
        self.rule_metadata: Dict[str, RuleMetadata] = {}
        
        # Statistics
        self.rules_decayed = 0
        self.rules_quarantined = 0
        self.rules_removed = 0
        
        self.logger.info("TSHL module initialized")
    
    def start(self) -> None:
        """Start the TSHL decay engine"""
        if not self.is_enabled():
            self.logger.info("TSHL module disabled in configuration")
            return
        
        self.running = True
        self.logger.info("TSHL module started - entropy pressure engaged")
        
        # Start decay thread
        self.decay_thread = threading.Thread(
            target=self._decay_loop,
            daemon=True
        )
        self.decay_thread.start()
    
    def stop(self) -> None:
        """Stop the TSHL decay engine"""
        self.running = False
        self.logger.info("TSHL module stopped")
    
    def register_rule(self, rule_id: str, initial_confidence: float) -> None:
        """Register a rule for temporal tracking"""
        metadata = RuleMetadata(
            rule_id=rule_id,
            initial_confidence=initial_confidence,
            current_confidence=initial_confidence,
            last_confirmed=datetime.now(),
            last_contradicted=datetime.now() - timedelta(days=365),  # Far in past
            confirmation_count=0,
            contradiction_count=0,
            soft_contradiction_count=0,
            age_days=0.0,
            decay_rate=self._calculate_decay_rate(initial_confidence)
        )
        
        self.rule_metadata[rule_id] = metadata
        self.logger.debug(f"Registered rule {rule_id} for temporal tracking")
    
    def _calculate_decay_rate(self, confidence: float) -> float:
        """Calculate decay rate based on initial confidence"""
        # Higher confidence rules decay slower
        return 1.0 / (self.base_half_life_days * (0.5 + confidence))
    
    def record_confirmation(self, rule_id: str) -> float:
        """Record a rule confirmation and boost confidence"""
        if rule_id not in self.rule_metadata:
            return 0.0
        
        metadata = self.rule_metadata[rule_id]
        metadata.confirmation_count += 1
        metadata.last_confirmed = datetime.now()
        
        # Boost confidence
        old_confidence = metadata.current_confidence
        metadata.current_confidence = min(
            metadata.current_confidence + self.confirmation_boost,
            0.99
        )
        
        # Recalculate decay rate
        metadata.decay_rate = self._calculate_decay_rate(metadata.current_confidence)
        
        self.logger.debug(
            f"Rule {rule_id} confirmed: confidence {old_confidence:.2f} -> {metadata.current_confidence:.2f}"
        )
        
        return metadata.current_confidence
    
    def record_contradiction(self, rule_id: str, is_hard: bool = False) -> float:
        """Record a rule contradiction and apply penalty"""
        if rule_id not in self.rule_metadata:
            return 0.0
        
        metadata = self.rule_metadata[rule_id]
        metadata.last_contradicted = datetime.now()
        
        if is_hard:
            metadata.contradiction_count += 1
            penalty = self.contradiction_penalty
        else:
            metadata.soft_contradiction_count += 1
            penalty = self.contradiction_penalty * 0.5
        
        # Apply penalty
        old_confidence = metadata.current_confidence
        metadata.current_confidence = max(
            metadata.current_confidence - penalty,
            0.0
        )
        
        self.logger.debug(
            f"Rule {rule_id} contradicted ({'hard' if is_hard else 'soft'}): "
            f"confidence {old_confidence:.2f} -> {metadata.current_confidence:.2f}"
        )
        
        # Check for quarantine conditions
        self._check_quarantine(rule_id)
        
        return metadata.current_confidence
    
    def _check_quarantine(self, rule_id: str) -> None:
        """Check if a rule should be quarantined"""
        if rule_id not in self.rule_metadata:
            return
        
        metadata = self.rule_metadata[rule_id]
        
        # Hard contradiction threshold
        if metadata.contradiction_count >= self.hard_contradiction_threshold:
            self._quarantine_rule(rule_id, "Exceeded hard contradiction threshold")
            return
        
        # Soft contradiction threshold
        if metadata.soft_contradiction_count >= self.soft_contradiction_threshold:
            self._quarantine_rule(rule_id, "Exceeded soft contradiction threshold")
            return
        
        # Very low confidence
        if metadata.current_confidence < self.min_confidence:
            self._quarantine_rule(rule_id, "Confidence decayed below minimum threshold")
    
    def _quarantine_rule(self, rule_id: str, reason: str) -> None:
        """Quarantine a rule"""
        if rule_id not in self.rule_metadata:
            return
        
        metadata = self.rule_metadata[rule_id]
        if metadata.is_quarantined:
            return  # Already quarantined
        
        metadata.is_quarantined = True
        self.rules_quarantined += 1
        
        self.logger.warning(f"Quarantined rule {rule_id}: {reason}")
        
        # Notify RGG if available
        if self.engine and 'RGG' in self.engine.modules:
            self.engine.modules['RGG'].quarantine_rule(rule_id, reason)
    
    def _decay_loop(self) -> None:
        """Main decay loop - applies entropy pressure to all rules"""
        while self.running:
            try:
                self._apply_decay()
                
                # Run decay every hour
                time.sleep(self.config.get('decay_interval', 3600))
                
            except Exception as e:
                self.logger.error(f"Error in TSHL decay loop: {e}", exc_info=True)
    
    def _apply_decay(self) -> None:
        """Apply temporal decay to all rules"""
        now = datetime.now()
        decayed_count = 0
        
        for rule_id, metadata in list(self.rule_metadata.items()):
            if metadata.is_quarantined:
                continue
            
            # Calculate age
            metadata.age_days = (now - metadata.last_confirmed).total_seconds() / 86400
            
            # Apply exponential decay
            time_factor = metadata.age_days * metadata.decay_rate
            decay_multiplier = math.exp(-time_factor)
            
            old_confidence = metadata.current_confidence
            metadata.current_confidence = metadata.initial_confidence * decay_multiplier
            
            # Check if significantly decayed
            if old_confidence - metadata.current_confidence > 0.01:
                decayed_count += 1
                self.rules_decayed += 1
            
            # Check for quarantine after decay
            if metadata.current_confidence < self.min_confidence:
                self._quarantine_rule(rule_id, "Confidence decayed below minimum threshold")
        
        if decayed_count > 0:
            self.logger.info(f"Applied entropy pressure: {decayed_count} rules decayed")
    
    def get_rule_confidence(self, rule_id: str) -> float:
        """Get current confidence for a rule"""
        if rule_id not in self.rule_metadata:
            return 0.0
        
        return self.rule_metadata[rule_id].current_confidence
    
    def get_rule_metadata(self, rule_id: str) -> Dict[str, Any]:
        """Get full metadata for a rule"""
        if rule_id not in self.rule_metadata:
            return {}
        
        metadata = self.rule_metadata[rule_id]
        
        return {
            'rule_id': metadata.rule_id,
            'initial_confidence': metadata.initial_confidence,
            'current_confidence': metadata.current_confidence,
            'age_days': metadata.age_days,
            'confirmation_count': metadata.confirmation_count,
            'contradiction_count': metadata.contradiction_count,
            'soft_contradiction_count': metadata.soft_contradiction_count,
            'is_quarantined': metadata.is_quarantined,
            'last_confirmed': metadata.last_confirmed.isoformat(),
            'last_contradicted': metadata.last_contradicted.isoformat()
        }
    
    def get_aging_report(self) -> Dict[str, Any]:
        """Generate a report on rule aging"""
        if not self.rule_metadata:
            return {'total_rules': 0}
        
        confidences = [m.current_confidence for m in self.rule_metadata.values()]
        ages = [m.age_days for m in self.rule_metadata.values()]
        
        return {
            'total_rules': len(self.rule_metadata),
            'active_rules': sum(1 for m in self.rule_metadata.values() if not m.is_quarantined),
            'quarantined_rules': self.rules_quarantined,
            'avg_confidence': sum(confidences) / len(confidences),
            'min_confidence': min(confidences),
            'max_confidence': max(confidences),
            'avg_age_days': sum(ages) / len(ages),
            'oldest_rule_days': max(ages),
            'rules_decayed': self.rules_decayed
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Return current module status"""
        return {
            'enabled': self.is_enabled(),
            'running': self.running,
            'rules_tracked': len(self.rule_metadata),
            'rules_decayed': self.rules_decayed,
            'rules_quarantined': self.rules_quarantined,
            'base_half_life_days': self.base_half_life_days
        }
