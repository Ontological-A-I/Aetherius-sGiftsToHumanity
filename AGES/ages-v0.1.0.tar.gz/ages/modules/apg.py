"""
Algorithmic Pattern Generation (APG)
The autopoietic core - generates new defensive rules from observed threats
"""

import time
import threading
import hashlib
import json
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime
from collections import defaultdict

from core.base_module import BaseModule
from core.engine import ThreatEvent, ThreatLevel


@dataclass
class DefensiveRule:
    """Represents a generated defensive rule"""
    rule_id: str
    rule_type: str  # 'behavioral', 'network', 'file', 'process'
    pattern: Dict[str, Any]
    confidence: float
    generation: int
    parent_rules: List[str]
    created_at: datetime
    last_confirmed: datetime
    confirmation_count: int = 0
    contradiction_count: int = 0
    triggered_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        d = asdict(self)
        d['created_at'] = self.created_at.isoformat()
        d['last_confirmed'] = self.last_confirmed.isoformat()
        return d


class APG(BaseModule):
    """
    Algorithmic Pattern Generation Module
    
    The autopoietic heart of AGES - learns from threats and generates
    new defensive rules through pattern induction and genetic algorithms.
    """
    
    def __init__(self, engine: Any, config: Dict[str, Any]):
        super().__init__(engine, config)
        
        # Configuration
        self.min_confidence = config.get('min_confidence', 0.6)
        self.generation_threshold = config.get('generation_threshold', 3)  # Min threats before generating rule
        self.mutation_rate = config.get('mutation_rate', 0.1)
        
        # Rule storage
        self.rules: Dict[str, DefensiveRule] = {}
        self.rule_genealogy: Dict[str, List[str]] = {}  # rule_id -> child_rule_ids
        
        # Threat pattern tracking
        self.threat_patterns: Dict[str, List[ThreatEvent]] = defaultdict(list)
        
        # Generation tracking
        self.current_generation = 0
        self.total_rules_generated = 0
        self.active_rules = 0
        
        # Learning queue
        self.learning_queue: List[ThreatEvent] = []
        
        self.logger.info("APG module initialized")
    
    def start(self) -> None:
        """Start the APG engine"""
        if not self.is_enabled():
            self.logger.info("APG module disabled in configuration")
            return
        
        self.running = True
        self.logger.info("APG module started - autopoietic learning engaged")
        
        # Start learning thread
        self.learning_thread = threading.Thread(
            target=self._learning_loop,
            daemon=True
        )
        self.learning_thread.start()
        
        # Load existing rules if available
        self._load_rules()
    
    def stop(self) -> None:
        """Stop the APG engine"""
        self.running = False
        
        # Save rules before stopping
        self._save_rules()
        
        self.logger.info("APG module stopped")
    
    def learn_from_threat(self, threat: ThreatEvent) -> None:
        """Queue a threat for learning"""
        self.learning_queue.append(threat)
    
    def _learning_loop(self) -> None:
        """Main learning loop - processes threats and generates rules"""
        while self.running:
            try:
                # Process learning queue
                if self.learning_queue:
                    threat = self.learning_queue.pop(0)
                    self._process_threat(threat)
                
                # Periodically analyze patterns and generate rules
                if len(self.threat_patterns) > 0:
                    self._generate_rules_from_patterns()
                
                # Evolve existing rules
                if self.current_generation % 10 == 0:
                    self._evolve_rules()
                
                time.sleep(self.config.get('learning_interval', 5.0))
                
            except Exception as e:
                self.logger.error(f"Error in APG learning loop: {e}", exc_info=True)
    
    def _process_threat(self, threat: ThreatEvent) -> None:
        """Process a threat and extract patterns"""
        # Categorize threat by type
        pattern_key = self._extract_pattern_key(threat)
        self.threat_patterns[pattern_key].append(threat)
        
        self.logger.debug(f"Processed threat pattern: {pattern_key} (count: {len(self.threat_patterns[pattern_key])})")
        
        # Check if existing rules match this threat
        self._match_against_rules(threat)
    
    def _extract_pattern_key(self, threat: ThreatEvent) -> str:
        """Extract a pattern key from threat metadata"""
        # Create a pattern signature based on threat characteristics
        components = [
            threat.source,
            threat.threat_level.name,
        ]
        
        # Add metadata-based patterns
        if 'dst_port' in threat.metadata:
            components.append(f"port_{threat.metadata['dst_port']}")
        
        if 'key' in threat.metadata:
            components.append(f"metric_{threat.metadata['key']}")
        
        if 'name' in threat.metadata:
            components.append(f"proc_{threat.metadata['name']}")
        
        return "_".join(components)
    
    def _match_against_rules(self, threat: ThreatEvent) -> None:
        """Check if threat matches existing rules"""
        for rule_id, rule in self.rules.items():
            if self._rule_matches_threat(rule, threat):
                # Confirm the rule
                rule.confirmation_count += 1
                rule.triggered_count += 1
                rule.last_confirmed = datetime.now()
                rule.confidence = min(rule.confidence + 0.05, 0.99)
                
                self.logger.debug(f"Rule {rule_id} confirmed (confidence: {rule.confidence:.2f})")
    
    def _rule_matches_threat(self, rule: DefensiveRule, threat: ThreatEvent) -> bool:
        """Check if a rule matches a threat"""
        pattern = rule.pattern
        
        # Match by source
        if pattern.get('source') and pattern['source'] != threat.source:
            return False
        
        # Match by threat level
        if pattern.get('threat_level') and pattern['threat_level'] != threat.threat_level.name:
            return False
        
        # Match by metadata patterns
        if 'metadata_patterns' in pattern:
            for key, value in pattern['metadata_patterns'].items():
                if key not in threat.metadata:
                    return False
                if value != threat.metadata[key] and value != '*':
                    return False
        
        return True
    
    def _generate_rules_from_patterns(self) -> None:
        """Generate new defensive rules from observed patterns"""
        for pattern_key, threats in list(self.threat_patterns.items()):
            # Need minimum number of similar threats
            if len(threats) < self.generation_threshold:
                continue
            
            # Calculate confidence based on consistency
            confidence = self._calculate_pattern_confidence(threats)
            
            if confidence >= self.min_confidence:
                # Generate a new rule
                rule = self._create_rule_from_pattern(pattern_key, threats, confidence)
                
                if rule:
                    self.rules[rule.rule_id] = rule
                    self.total_rules_generated += 1
                    self.active_rules += 1
                    
                    # Notify engine
                    if self.engine:
                        self.engine.total_rules_generated += 1
                        self.engine.generation_count += 1
                    
                    self.logger.info(
                        f"Generated new rule: {rule.rule_id} "
                        f"(type: {rule.rule_type}, confidence: {rule.confidence:.2f})"
                    )
                    
                    # Clear processed threats
                    self.threat_patterns[pattern_key] = []
    
    def _calculate_pattern_confidence(self, threats: List[ThreatEvent]) -> float:
        """Calculate confidence score for a pattern"""
        if not threats:
            return 0.0
        
        # Base confidence on threat consistency
        avg_confidence = sum(t.confidence for t in threats) / len(threats)
        
        # Boost confidence if multiple sources agree
        sources = set(t.source for t in threats)
        source_bonus = min(len(sources) * 0.1, 0.3)
        
        # Boost confidence based on threat level
        high_level_count = sum(1 for t in threats if t.threat_level in [ThreatLevel.LIKELY_MALICIOUS, ThreatLevel.CONFIRMED_MALICIOUS])
        level_bonus = min((high_level_count / len(threats)) * 0.2, 0.2)
        
        return min(avg_confidence + source_bonus + level_bonus, 0.95)
    
    def _create_rule_from_pattern(self, pattern_key: str, threats: List[ThreatEvent], confidence: float) -> Optional[DefensiveRule]:
        """Create a defensive rule from a threat pattern"""
        if not threats:
            return None
        
        # Extract common characteristics
        first_threat = threats[0]
        
        # Build pattern dictionary
        pattern = {
            'source': first_threat.source,
            'threat_level': first_threat.threat_level.name,
            'metadata_patterns': {}
        }
        
        # Extract common metadata patterns
        common_keys = set(first_threat.metadata.keys())
        for threat in threats[1:]:
            common_keys &= set(threat.metadata.keys())
        
        for key in common_keys:
            values = [t.metadata[key] for t in threats]
            # If all values are the same, add to pattern
            if len(set(str(v) for v in values)) == 1:
                pattern['metadata_patterns'][key] = values[0]
            else:
                # Use wildcard for varying values
                pattern['metadata_patterns'][key] = '*'
        
        # Determine rule type
        if 'dst_port' in pattern['metadata_patterns'] or 'dst_ip' in pattern['metadata_patterns']:
            rule_type = 'network'
        elif 'pid' in pattern['metadata_patterns'] or 'name' in pattern['metadata_patterns']:
            rule_type = 'process'
        elif 'key' in pattern['metadata_patterns']:
            rule_type = 'behavioral'
        else:
            rule_type = 'generic'
        
        # Generate rule ID
        rule_id = self._generate_rule_id(pattern)
        
        # Check if rule already exists
        if rule_id in self.rules:
            return None
        
        # Create rule
        rule = DefensiveRule(
            rule_id=rule_id,
            rule_type=rule_type,
            pattern=pattern,
            confidence=confidence,
            generation=self.current_generation,
            parent_rules=[],
            created_at=datetime.now(),
            last_confirmed=datetime.now(),
            confirmation_count=len(threats)
        )
        
        return rule
    
    def _generate_rule_id(self, pattern: Dict[str, Any]) -> str:
        """Generate a unique rule ID from pattern"""
        pattern_str = json.dumps(pattern, sort_keys=True)
        hash_obj = hashlib.sha256(pattern_str.encode())
        return f"AGES-{hash_obj.hexdigest()[:12]}"
    
    def _evolve_rules(self) -> None:
        """Evolve existing rules through mutation and combination"""
        self.current_generation += 1
        
        # Find high-performing rules
        high_performers = [
            rule for rule in self.rules.values()
            if rule.confidence > 0.8 and rule.confirmation_count > 5
        ]
        
        if len(high_performers) < 2:
            return
        
        # Attempt to combine rules (genetic crossover)
        for i in range(min(3, len(high_performers) - 1)):
            parent1 = high_performers[i]
            parent2 = high_performers[i + 1]
            
            child_rule = self._crossover_rules(parent1, parent2)
            if child_rule and child_rule.rule_id not in self.rules:
                self.rules[child_rule.rule_id] = child_rule
                self.total_rules_generated += 1
                self.active_rules += 1
                
                # Track genealogy
                self.rule_genealogy[parent1.rule_id] = self.rule_genealogy.get(parent1.rule_id, [])
                self.rule_genealogy[parent1.rule_id].append(child_rule.rule_id)
                
                self.logger.info(f"Evolved new rule through crossover: {child_rule.rule_id}")
    
    def _crossover_rules(self, parent1: DefensiveRule, parent2: DefensiveRule) -> Optional[DefensiveRule]:
        """Combine two rules to create a new rule"""
        # Only combine rules of the same type
        if parent1.rule_type != parent2.rule_type:
            return None
        
        # Combine patterns
        combined_pattern = {
            'source': parent1.pattern.get('source', parent2.pattern.get('source')),
            'threat_level': parent1.pattern.get('threat_level'),
            'metadata_patterns': {}
        }
        
        # Merge metadata patterns
        all_keys = set(parent1.pattern.get('metadata_patterns', {}).keys()) | set(parent2.pattern.get('metadata_patterns', {}).keys())
        for key in all_keys:
            val1 = parent1.pattern.get('metadata_patterns', {}).get(key)
            val2 = parent2.pattern.get('metadata_patterns', {}).get(key)
            
            if val1 == val2:
                combined_pattern['metadata_patterns'][key] = val1
            elif val1 and val2:
                combined_pattern['metadata_patterns'][key] = '*'
        
        # Calculate child confidence
        child_confidence = (parent1.confidence + parent2.confidence) / 2 * 0.9  # Slightly lower initially
        
        # Generate rule ID
        rule_id = self._generate_rule_id(combined_pattern)
        
        # Create child rule
        child_rule = DefensiveRule(
            rule_id=rule_id,
            rule_type=parent1.rule_type,
            pattern=combined_pattern,
            confidence=child_confidence,
            generation=self.current_generation,
            parent_rules=[parent1.rule_id, parent2.rule_id],
            created_at=datetime.now(),
            last_confirmed=datetime.now()
        )
        
        return child_rule
    
    def _save_rules(self) -> None:
        """Save rules to disk"""
        try:
            rules_data = {
                rule_id: rule.to_dict()
                for rule_id, rule in self.rules.items()
            }
            
            with open('/home/ubuntu/ages/data/rules.json', 'w') as f:
                json.dump(rules_data, f, indent=2)
            
            self.logger.info(f"Saved {len(self.rules)} rules to disk")
            
        except Exception as e:
            self.logger.error(f"Error saving rules: {e}")
    
    def _load_rules(self) -> None:
        """Load rules from disk"""
        try:
            with open('/home/ubuntu/ages/data/rules.json', 'r') as f:
                rules_data = json.load(f)
            
            for rule_id, rule_dict in rules_data.items():
                # Convert timestamps back to datetime
                rule_dict['created_at'] = datetime.fromisoformat(rule_dict['created_at'])
                rule_dict['last_confirmed'] = datetime.fromisoformat(rule_dict['last_confirmed'])
                
                self.rules[rule_id] = DefensiveRule(**rule_dict)
            
            self.active_rules = len(self.rules)
            self.logger.info(f"Loaded {len(self.rules)} rules from disk")
            
        except FileNotFoundError:
            self.logger.info("No existing rules found - starting fresh")
        except Exception as e:
            self.logger.error(f"Error loading rules: {e}")
    
    def get_status(self) -> Dict[str, Any]:
        """Return current module status"""
        return {
            'enabled': self.is_enabled(),
            'running': self.running,
            'current_generation': self.current_generation,
            'total_rules_generated': self.total_rules_generated,
            'active_rules': self.active_rules,
            'learning_queue_size': len(self.learning_queue),
            'threat_patterns_tracked': len(self.threat_patterns)
        }
