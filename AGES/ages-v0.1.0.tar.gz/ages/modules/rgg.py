"""
Rule Genealogy Graph (RGG)
Tracks the lineage and evolution of defensive rules for traceability and auditing
"""

import json
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, asdict
from datetime import datetime
from collections import defaultdict

from core.base_module import BaseModule


@dataclass
class RuleNode:
    """Represents a node in the rule genealogy graph"""
    rule_id: str
    parent_ids: List[str]
    child_ids: List[str]
    generation: int
    created_at: datetime
    sensor_origins: List[str]  # Which sensors contributed to this rule
    validation_pathway: str  # How the rule was validated
    mutation_steps: List[str]  # History of mutations
    performance_score: float = 0.0
    is_active: bool = True
    is_quarantined: bool = False
    quarantine_reason: Optional[str] = None


class RGG(BaseModule):
    """
    Rule Genealogy Graph Module
    
    Maintains a complete genealogical record of all rules, enabling:
    - Causal traceability for every decision
    - Identification of poisoned lineages
    - Intelligent rollback capabilities
    - Performance tracking across generations
    """
    
    def __init__(self, engine: Any, config: Dict[str, Any]):
        super().__init__(engine, config)
        
        # Graph storage
        self.nodes: Dict[str, RuleNode] = {}
        self.lineages: Dict[str, Set[str]] = defaultdict(set)  # parent -> all descendants
        
        # Performance tracking
        self.lineage_performance: Dict[str, float] = {}
        
        # Statistics
        self.total_nodes = 0
        self.quarantined_nodes = 0
        self.active_lineages = 0
        
        self.logger.info("RGG module initialized")
    
    def start(self) -> None:
        """Start the RGG module"""
        if not self.is_enabled():
            self.logger.info("RGG module disabled in configuration")
            return
        
        self.running = True
        self.logger.info("RGG module started")
        
        # Load existing graph
        self._load_graph()
    
    def stop(self) -> None:
        """Stop the RGG module"""
        self.running = False
        
        # Save graph
        self._save_graph()
        
        self.logger.info("RGG module stopped")
    
    def register_rule(self, rule_id: str, parent_ids: List[str], generation: int,
                     sensor_origins: List[str], validation_pathway: str) -> None:
        """Register a new rule in the genealogy graph"""
        
        # Create node
        node = RuleNode(
            rule_id=rule_id,
            parent_ids=parent_ids,
            child_ids=[],
            generation=generation,
            created_at=datetime.now(),
            sensor_origins=sensor_origins,
            validation_pathway=validation_pathway,
            mutation_steps=[]
        )
        
        self.nodes[rule_id] = node
        self.total_nodes += 1
        
        # Update parent nodes
        for parent_id in parent_ids:
            if parent_id in self.nodes:
                self.nodes[parent_id].child_ids.append(rule_id)
        
        # Track lineage
        self._update_lineages(rule_id, parent_ids)
        
        self.logger.debug(f"Registered rule {rule_id} in genealogy graph")
    
    def _update_lineages(self, rule_id: str, parent_ids: List[str]) -> None:
        """Update lineage tracking"""
        for parent_id in parent_ids:
            # Add this rule to parent's lineage
            self.lineages[parent_id].add(rule_id)
            
            # Inherit grandparent lineages
            if parent_id in self.lineages:
                self.lineages[parent_id].update(self.lineages[parent_id])
    
    def record_mutation(self, rule_id: str, mutation_description: str) -> None:
        """Record a mutation in a rule's history"""
        if rule_id in self.nodes:
            self.nodes[rule_id].mutation_steps.append(
                f"{datetime.now().isoformat()}: {mutation_description}"
            )
            self.logger.debug(f"Recorded mutation for rule {rule_id}")
    
    def update_performance(self, rule_id: str, performance_score: float) -> None:
        """Update performance score for a rule"""
        if rule_id in self.nodes:
            node = self.nodes[rule_id]
            node.performance_score = performance_score
            
            # Update lineage performance
            self._update_lineage_performance(rule_id)
    
    def _update_lineage_performance(self, rule_id: str) -> None:
        """Update aggregate performance for entire lineage"""
        if rule_id not in self.nodes:
            return
        
        node = self.nodes[rule_id]
        
        # Calculate lineage performance (average of all descendants)
        descendants = self.lineages.get(rule_id, set())
        if descendants:
            scores = [self.nodes[desc_id].performance_score 
                     for desc_id in descendants 
                     if desc_id in self.nodes]
            
            if scores:
                self.lineage_performance[rule_id] = sum(scores) / len(scores)
    
    def quarantine_rule(self, rule_id: str, reason: str) -> None:
        """Quarantine a rule and potentially its lineage"""
        if rule_id not in self.nodes:
            self.logger.warning(f"Cannot quarantine unknown rule: {rule_id}")
            return
        
        node = self.nodes[rule_id]
        node.is_quarantined = True
        node.is_active = False
        node.quarantine_reason = reason
        self.quarantined_nodes += 1
        
        self.logger.warning(f"Quarantined rule {rule_id}: {reason}")
        
        # Check if entire lineage should be quarantined
        if "poisoned" in reason.lower() or "malicious" in reason.lower():
            self._quarantine_lineage(rule_id, reason)
    
    def _quarantine_lineage(self, rule_id: str, reason: str) -> None:
        """Quarantine an entire lineage"""
        descendants = self.lineages.get(rule_id, set())
        
        quarantined_count = 0
        for desc_id in descendants:
            if desc_id in self.nodes and not self.nodes[desc_id].is_quarantined:
                self.nodes[desc_id].is_quarantined = True
                self.nodes[desc_id].is_active = False
                self.nodes[desc_id].quarantine_reason = f"Inherited from {rule_id}: {reason}"
                self.quarantined_nodes += 1
                quarantined_count += 1
        
        if quarantined_count > 0:
            self.logger.warning(
                f"Quarantined {quarantined_count} rules in lineage of {rule_id}"
            )
    
    def get_rule_ancestry(self, rule_id: str, max_depth: int = 5) -> List[str]:
        """Get the ancestry chain of a rule"""
        if rule_id not in self.nodes:
            return []
        
        ancestry = []
        current_ids = [rule_id]
        
        for _ in range(max_depth):
            if not current_ids:
                break
            
            next_ids = []
            for curr_id in current_ids:
                if curr_id in self.nodes:
                    ancestry.append(curr_id)
                    next_ids.extend(self.nodes[curr_id].parent_ids)
            
            current_ids = next_ids
        
        return ancestry
    
    def get_rule_descendants(self, rule_id: str) -> Set[str]:
        """Get all descendants of a rule"""
        return self.lineages.get(rule_id, set())
    
    def get_lineage_report(self, rule_id: str) -> Dict[str, Any]:
        """Generate a detailed lineage report for a rule"""
        if rule_id not in self.nodes:
            return {'error': 'Rule not found'}
        
        node = self.nodes[rule_id]
        ancestry = self.get_rule_ancestry(rule_id)
        descendants = self.get_rule_descendants(rule_id)
        
        return {
            'rule_id': rule_id,
            'generation': node.generation,
            'created_at': node.created_at.isoformat(),
            'sensor_origins': node.sensor_origins,
            'validation_pathway': node.validation_pathway,
            'performance_score': node.performance_score,
            'is_active': node.is_active,
            'is_quarantined': node.is_quarantined,
            'quarantine_reason': node.quarantine_reason,
            'parent_count': len(node.parent_ids),
            'child_count': len(node.child_ids),
            'ancestry_depth': len(ancestry),
            'descendant_count': len(descendants),
            'mutation_count': len(node.mutation_steps),
            'lineage_performance': self.lineage_performance.get(rule_id, 0.0)
        }
    
    def identify_best_lineages(self, top_n: int = 5) -> List[Tuple[str, float]]:
        """Identify the best-performing lineages"""
        lineage_scores = [
            (rule_id, score)
            for rule_id, score in self.lineage_performance.items()
            if rule_id in self.nodes and self.nodes[rule_id].is_active
        ]
        
        lineage_scores.sort(key=lambda x: x[1], reverse=True)
        return lineage_scores[:top_n]
    
    def rollback_to_generation(self, target_generation: int) -> List[str]:
        """Rollback rules to a specific generation"""
        deactivated = []
        
        for rule_id, node in self.nodes.items():
            if node.generation > target_generation and node.is_active:
                node.is_active = False
                deactivated.append(rule_id)
        
        self.logger.info(f"Rolled back {len(deactivated)} rules to generation {target_generation}")
        return deactivated
    
    def _save_graph(self) -> None:
        """Save genealogy graph to disk"""
        try:
            graph_data = {
                'nodes': {},
                'lineages': {}
            }
            
            # Convert nodes to dict
            for rule_id, node in self.nodes.items():
                node_dict = asdict(node)
                node_dict['created_at'] = node.created_at.isoformat()
                graph_data['nodes'][rule_id] = node_dict
            
            # Convert lineages to dict
            for parent_id, descendants in self.lineages.items():
                graph_data['lineages'][parent_id] = list(descendants)
            
            with open('/home/ubuntu/ages/data/genealogy.json', 'w') as f:
                json.dump(graph_data, f, indent=2)
            
            self.logger.info(f"Saved genealogy graph with {len(self.nodes)} nodes")
            
        except Exception as e:
            self.logger.error(f"Error saving genealogy graph: {e}")
    
    def _load_graph(self) -> None:
        """Load genealogy graph from disk"""
        try:
            with open('/home/ubuntu/ages/data/genealogy.json', 'r') as f:
                graph_data = json.load(f)
            
            # Load nodes
            for rule_id, node_dict in graph_data['nodes'].items():
                node_dict['created_at'] = datetime.fromisoformat(node_dict['created_at'])
                self.nodes[rule_id] = RuleNode(**node_dict)
            
            # Load lineages
            for parent_id, descendants in graph_data['lineages'].items():
                self.lineages[parent_id] = set(descendants)
            
            self.total_nodes = len(self.nodes)
            self.quarantined_nodes = sum(1 for n in self.nodes.values() if n.is_quarantined)
            
            self.logger.info(f"Loaded genealogy graph with {len(self.nodes)} nodes")
            
        except FileNotFoundError:
            self.logger.info("No existing genealogy graph found - starting fresh")
        except Exception as e:
            self.logger.error(f"Error loading genealogy graph: {e}")
    
    def get_status(self) -> Dict[str, Any]:
        """Return current module status"""
        return {
            'enabled': self.is_enabled(),
            'running': self.running,
            'total_nodes': self.total_nodes,
            'active_nodes': sum(1 for n in self.nodes.values() if n.is_active),
            'quarantined_nodes': self.quarantined_nodes,
            'active_lineages': len(self.lineages)
        }
