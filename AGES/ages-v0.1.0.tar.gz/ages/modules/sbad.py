"""
Statistical Behavioral Anomaly Detection (SBAD)
Creates statistical profiles and detects deviations indicating malicious behavior
"""

import time
import threading
import numpy as np
from typing import Dict, List, Any, Tuple
from collections import deque, defaultdict
from dataclasses import dataclass
from datetime import datetime

from core.base_module import BaseModule
from core.engine import ThreatEvent, ThreatLevel


@dataclass
class BehaviorProfile:
    """Statistical profile of normal behavior"""
    mean: float
    std: float
    median: float
    mad: float  # Median Absolute Deviation
    samples: int
    last_updated: datetime


class SBAD(BaseModule):
    """
    Statistical Behavioral Anomaly Detection Module
    
    Monitors system calls, resource usage, and process behaviors to detect
    statistically significant deviations from established baselines.
    """
    
    def __init__(self, engine: Any, config: Dict[str, Any]):
        super().__init__(engine, config)
        
        # Configuration
        self.window_size = config.get('window_size', 100)
        self.z_score_threshold = config.get('z_score_threshold', 3.0)
        self.mad_threshold = config.get('mad_threshold', 3.5)
        self.learning_period = config.get('learning_period', 300)  # seconds
        
        # Behavioral profiles
        self.profiles: Dict[str, BehaviorProfile] = {}
        
        # Recent observations (sliding window)
        self.observations: Dict[str, deque] = defaultdict(lambda: deque(maxlen=self.window_size))
        
        # Process tracking
        self.process_behaviors: Dict[int, Dict[str, Any]] = {}
        
        # Statistics
        self.anomalies_detected = 0
        self.false_positives = 0
        
        # Learning mode
        self.learning_mode = True
        self.learning_start_time = time.time()
        
        self.logger.info("SBAD module initialized")
    
    def start(self) -> None:
        """Start the SBAD monitoring"""
        if not self.is_enabled():
            self.logger.info("SBAD module disabled in configuration")
            return
        
        self.running = True
        self.logger.info("SBAD module started")
        
        # Start monitoring thread
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            daemon=True
        )
        self.monitor_thread.start()
    
    def stop(self) -> None:
        """Stop the SBAD monitoring"""
        self.running = False
        self.logger.info("SBAD module stopped")
    
    def _monitoring_loop(self) -> None:
        """Main monitoring loop"""
        while self.running:
            try:
                # Check if still in learning mode
                if self.learning_mode:
                    elapsed = time.time() - self.learning_start_time
                    if elapsed >= self.learning_period:
                        self.learning_mode = False
                        self._build_profiles()
                        self.logger.info("SBAD learning period complete - active monitoring engaged")
                
                # Monitor system behaviors
                self._monitor_cpu_behavior()
                self._monitor_memory_behavior()
                self._monitor_process_behavior()
                self._monitor_network_behavior()
                
                # Sleep interval
                time.sleep(self.config.get('scan_interval', 2.0))
                
            except Exception as e:
                self.logger.error(f"Error in SBAD monitoring loop: {e}", exc_info=True)
    
    def _monitor_cpu_behavior(self) -> None:
        """Monitor CPU usage patterns"""
        try:
            import psutil
            
            cpu_percent = psutil.cpu_percent(interval=0.1)
            self.observations['cpu_usage'].append(cpu_percent)
            
            if not self.learning_mode:
                self._check_anomaly('cpu_usage', cpu_percent)
                
        except ImportError:
            pass
    
    def _monitor_memory_behavior(self) -> None:
        """Monitor memory usage patterns"""
        try:
            import psutil
            
            mem = psutil.virtual_memory()
            self.observations['memory_usage'].append(mem.percent)
            
            if not self.learning_mode:
                self._check_anomaly('memory_usage', mem.percent)
                
        except ImportError:
            pass
    
    def _monitor_process_behavior(self) -> None:
        """Monitor individual process behaviors"""
        try:
            import psutil
            
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'num_threads']):
                try:
                    pid = proc.info['pid']
                    name = proc.info['name']
                    
                    # Track process metrics
                    key = f"proc_{pid}_cpu"
                    self.observations[key].append(proc.info['cpu_percent'])
                    
                    key = f"proc_{pid}_mem"
                    self.observations[key].append(proc.info['memory_percent'])
                    
                    key = f"proc_{pid}_threads"
                    self.observations[key].append(proc.info['num_threads'])
                    
                    # Check for anomalies in established processes
                    if not self.learning_mode and len(self.observations[f"proc_{pid}_cpu"]) >= 10:
                        cpu_anomaly = self._check_anomaly(f"proc_{pid}_cpu", proc.info['cpu_percent'], silent=True)
                        mem_anomaly = self._check_anomaly(f"proc_{pid}_mem", proc.info['memory_percent'], silent=True)
                        thread_anomaly = self._check_anomaly(f"proc_{pid}_threads", proc.info['num_threads'], silent=True)
                        
                        # If multiple anomalies detected, report threat
                        anomaly_count = sum([cpu_anomaly, mem_anomaly, thread_anomaly])
                        if anomaly_count >= 2:
                            self._report_process_anomaly(proc, anomaly_count)
                    
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                    
        except ImportError:
            pass
    
    def _monitor_network_behavior(self) -> None:
        """Monitor network activity patterns"""
        try:
            import psutil
            
            net = psutil.net_io_counters()
            
            # Track bytes sent/received
            self.observations['net_sent'].append(net.bytes_sent)
            self.observations['net_recv'].append(net.bytes_recv)
            
            # Calculate rates if we have previous data
            if len(self.observations['net_sent']) >= 2:
                sent_rate = self.observations['net_sent'][-1] - self.observations['net_sent'][-2]
                recv_rate = self.observations['net_recv'][-1] - self.observations['net_recv'][-2]
                
                self.observations['net_sent_rate'].append(sent_rate)
                self.observations['net_recv_rate'].append(recv_rate)
                
                if not self.learning_mode:
                    self._check_anomaly('net_sent_rate', sent_rate)
                    self._check_anomaly('net_recv_rate', recv_rate)
                    
        except ImportError:
            pass
    
    def _build_profiles(self) -> None:
        """Build statistical profiles from collected observations"""
        self.logger.info("Building behavioral profiles...")
        
        for key, obs_deque in self.observations.items():
            if len(obs_deque) < 10:  # Need minimum samples
                continue
            
            data = np.array(list(obs_deque))
            
            # Calculate statistics
            mean = np.mean(data)
            std = np.std(data)
            median = np.median(data)
            mad = np.median(np.abs(data - median))
            
            self.profiles[key] = BehaviorProfile(
                mean=mean,
                std=std,
                median=median,
                mad=mad,
                samples=len(data),
                last_updated=datetime.now()
            )
        
        self.logger.info(f"Built {len(self.profiles)} behavioral profiles")
    
    def _check_anomaly(self, key: str, value: float, silent: bool = False) -> bool:
        """Check if a value is anomalous based on statistical profile"""
        if key not in self.profiles:
            return False
        
        profile = self.profiles[key]
        
        # Z-score method (for normal distributions)
        if profile.std > 0:
            z_score = abs((value - profile.mean) / profile.std)
            if z_score > self.z_score_threshold:
                if not silent:
                    self._report_anomaly(key, value, z_score, "z-score")
                return True
        
        # MAD method (more robust to outliers)
        if profile.mad > 0:
            mad_score = abs((value - profile.median) / (1.4826 * profile.mad))
            if mad_score > self.mad_threshold:
                if not silent:
                    self._report_anomaly(key, value, mad_score, "MAD")
                return True
        
        return False
    
    def _report_anomaly(self, key: str, value: float, score: float, method: str) -> None:
        """Report detected anomaly"""
        self.anomalies_detected += 1
        
        threat = ThreatEvent(
            timestamp=datetime.now(),
            source="SBAD",
            threat_level=ThreatLevel.SUSPICIOUS,
            confidence=min(score / 10.0, 0.9),  # Convert score to confidence
            description=f"Statistical anomaly in {key}: {value:.2f} (score: {score:.2f}, method: {method})",
            metadata={'key': key, 'value': value, 'score': score, 'method': method}
        )
        
        self.report_threat(threat)
    
    def _report_process_anomaly(self, proc: Any, anomaly_count: int) -> None:
        """Report anomalous process behavior"""
        confidence = min(0.5 + (anomaly_count * 0.2), 0.95)
        
        threat = ThreatEvent(
            timestamp=datetime.now(),
            source="SBAD",
            threat_level=ThreatLevel.LIKELY_MALICIOUS if anomaly_count >= 3 else ThreatLevel.SUSPICIOUS,
            confidence=confidence,
            description=f"Anomalous behavior detected in process: {proc.info['name']} (PID: {proc.info['pid']})",
            metadata={
                'pid': proc.info['pid'],
                'name': proc.info['name'],
                'anomaly_count': anomaly_count,
                'target': proc.info['name']
            }
        )
        
        self.report_threat(threat)
    
    def get_status(self) -> Dict[str, Any]:
        """Return current module status"""
        return {
            'enabled': self.is_enabled(),
            'running': self.running,
            'learning_mode': self.learning_mode,
            'profiles_count': len(self.profiles),
            'anomalies_detected': self.anomalies_detected,
            'observations_tracked': len(self.observations)
        }
