"""
Base module interface for all AGES components
"""

from abc import ABC, abstractmethod
from typing import Any, Dict
import logging


class BaseModule(ABC):
    """
    Abstract base class for all AGES modules.
    Ensures consistent interface and integration with the core engine.
    """
    
    def __init__(self, engine: Any, config: Dict[str, Any]):
        self.engine = engine
        self.config = config
        self.running = False
        self.logger = logging.getLogger(f"AGES.{self.__class__.__name__}")
        self.enabled = config.get('enabled', True)
    
    @abstractmethod
    def start(self) -> None:
        """Start the module's operation"""
        pass
    
    @abstractmethod
    def stop(self) -> None:
        """Stop the module's operation"""
        pass
    
    @abstractmethod
    def get_status(self) -> Dict[str, Any]:
        """Return current module status"""
        pass
    
    def is_enabled(self) -> bool:
        """Check if module is enabled in configuration"""
        return self.enabled
    
    def report_threat(self, threat: Any) -> None:
        """Report a detected threat to the core engine"""
        if self.engine:
            self.engine.report_threat(threat)
