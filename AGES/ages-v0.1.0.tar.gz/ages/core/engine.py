"""
AetherGuard Edge Sentinel (AGES) - Core Engine
The autopoietic heart of the system.
"""

import time
import threading
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class ThreatLevel(Enum):
    """Threat severity levels"""
    BENIGN = 0
    SUSPICIOUS = 1
    LIKELY_MALICIOUS = 2
    CONFIRMED_MALICIOUS = 3


@dataclass
class ThreatEvent:
    """Represents a detected threat or anomaly"""
    timestamp: datetime
    source: str  # Which module detected it
    threat_level: ThreatLevel
    confidence: float  # 0.0 to 1.0
    description: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    rule_id: Optional[str] = None
    

@dataclass
class SystemMetrics:
    """Real-time system resource metrics"""
    cpu_usage: float
    memory_usage: float
    disk_io: float
    network_io: float
    timestamp: datetime = field(default_factory=datetime.now)


class AutopoieticEngine:
    """
    The core autopoietic engine of AGES.
    Coordinates all modules, manages self-improvement, and ensures system integrity.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.running = False
        self.modules: Dict[str, Any] = {}
        self.threat_queue: List[ThreatEvent] = []
        self.metrics_history: List[SystemMetrics] = []
        
        # Setup logging
        self.logger = self._setup_logging()
        
        # Thread management
        self.threads: List[threading.Thread] = []
        self.lock = threading.Lock()
        
        # Autopoietic state
        self.generation_count = 0  # Number of self-improvement cycles
        self.total_rules_generated = 0
        self.total_threats_blocked = 0
        
        self.logger.info("AGES Autopoietic Engine initialized")
    
    def _setup_logging(self) -> logging.Logger:
        """Configure logging system"""
        logger = logging.getLogger("AGES")
        logger.setLevel(logging.INFO)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # File handler
        file_handler = logging.FileHandler("/home/ubuntu/ages/logs/ages.log")
        file_handler.setLevel(logging.DEBUG)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(formatter)
        file_handler.setFormatter(formatter)
        
        logger.addHandler(console_handler)
        logger.addHandler(file_handler)
        
        return logger
    
    def register_module(self, name: str, module: Any) -> None:
        """Register a defensive or autopoietic module"""
        with self.lock:
            self.modules[name] = module
            self.logger.info(f"Module registered: {name}")
    
    def start(self) -> None:
        """Start the AGES engine and all registered modules"""
        if self.running:
            self.logger.warning("Engine already running")
            return
        
        self.running = True
        self.logger.info("Starting AGES Engine...")
        
        # Start all registered modules
        for name, module in self.modules.items():
            if hasattr(module, 'start'):
                thread = threading.Thread(
                    target=module.start,
                    name=f"AGES-{name}",
                    daemon=True
                )
                thread.start()
                self.threads.append(thread)
                self.logger.info(f"Module started: {name}")
        
        # Start core monitoring loop
        monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            name="AGES-Monitor",
            daemon=True
        )
        monitor_thread.start()
        self.threads.append(monitor_thread)
        
        self.logger.info("AGES Engine fully operational")
    
    def stop(self) -> None:
        """Gracefully stop the AGES engine"""
        self.logger.info("Stopping AGES Engine...")
        self.running = False
        
        # Stop all modules
        for name, module in self.modules.items():
            if hasattr(module, 'stop'):
                module.stop()
                self.logger.info(f"Module stopped: {name}")
        
        # Wait for threads to complete
        for thread in self.threads:
            thread.join(timeout=5.0)
        
        self.logger.info("AGES Engine stopped")
    
    def _monitoring_loop(self) -> None:
        """Main monitoring loop - the heartbeat of AGES"""
        while self.running:
            try:
                # Collect system metrics
                metrics = self._collect_metrics()
                
                with self.lock:
                    self.metrics_history.append(metrics)
                    
                    # Keep only recent history (last 1000 samples)
                    if len(self.metrics_history) > 1000:
                        self.metrics_history = self.metrics_history[-1000:]
                    
                    # Process threat queue
                    self._process_threat_queue()
                
                # Sleep interval based on config
                time.sleep(self.config.get('monitor_interval', 1.0))
                
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}", exc_info=True)
    
    def _collect_metrics(self) -> SystemMetrics:
        """Collect current system resource metrics"""
        try:
            import psutil
            
            return SystemMetrics(
                cpu_usage=psutil.cpu_percent(interval=0.1),
                memory_usage=psutil.virtual_memory().percent,
                disk_io=psutil.disk_io_counters().read_bytes + psutil.disk_io_counters().write_bytes,
                network_io=psutil.net_io_counters().bytes_sent + psutil.net_io_counters().bytes_recv
            )
        except ImportError:
            # Fallback if psutil not available
            return SystemMetrics(
                cpu_usage=0.0,
                memory_usage=0.0,
                disk_io=0.0,
                network_io=0.0
            )
    
    def _process_threat_queue(self) -> None:
        """Process detected threats and coordinate responses"""
        if not self.threat_queue:
            return
        
        # Process each threat
        for threat in self.threat_queue[:]:
            self.logger.info(
                f"Processing threat: {threat.description} "
                f"(Level: {threat.threat_level.name}, Confidence: {threat.confidence:.2f})"
            )
            
            # Determine response based on threat level and confidence
            if threat.threat_level == ThreatLevel.CONFIRMED_MALICIOUS and threat.confidence >= 0.95:
                self._execute_autonomous_remediation(threat)
            elif threat.threat_level == ThreatLevel.LIKELY_MALICIOUS and threat.confidence >= 0.75:
                self._execute_cautious_response(threat)
            else:
                self._log_for_learning(threat)
            
            # Remove processed threat
            self.threat_queue.remove(threat)
    
    def _execute_autonomous_remediation(self, threat: ThreatEvent) -> None:
        """Execute autonomous remediation for confirmed threats"""
        self.logger.warning(f"AUTONOMOUS REMEDIATION: {threat.description}")
        
        # Notify user
        self._notify_user(
            f"Threat Quarantined: {threat.metadata.get('target', 'Unknown')} - "
            f"{threat.description}"
        )
        
        # Increment counter
        self.total_threats_blocked += 1
        
        # Trigger APG to learn from this threat
        if 'APG' in self.modules:
            self.modules['APG'].learn_from_threat(threat)
    
    def _execute_cautious_response(self, threat: ThreatEvent) -> None:
        """Execute cautious response for likely threats"""
        self.logger.warning(f"CAUTIOUS RESPONSE: {threat.description}")
        
        # Enter Non-Intervention Learning Mode (NILM)
        if 'NILM' in self.modules:
            self.modules['NILM'].observe(threat)
    
    def _log_for_learning(self, threat: ThreatEvent) -> None:
        """Log suspicious activity for learning without intervention"""
        self.logger.debug(f"LEARNING MODE: {threat.description}")
    
    def _notify_user(self, message: str) -> None:
        """Send concise notification to user"""
        # In production, this would use OS notifications
        print(f"\n[AGES ALERT] {message}\n")
        self.logger.info(f"User notification: {message}")
    
    def report_threat(self, threat: ThreatEvent) -> None:
        """Called by modules to report detected threats"""
        with self.lock:
            self.threat_queue.append(threat)
    
    def get_status(self) -> Dict[str, Any]:
        """Get current engine status"""
        with self.lock:
            return {
                'running': self.running,
                'modules_active': len(self.modules),
                'generation_count': self.generation_count,
                'rules_generated': self.total_rules_generated,
                'threats_blocked': self.total_threats_blocked,
                'pending_threats': len(self.threat_queue),
                'uptime': time.time()
            }
