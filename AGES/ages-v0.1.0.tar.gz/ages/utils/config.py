"""
Configuration management for AGES
"""

import json
import yaml
from typing import Dict, Any
from pathlib import Path


def get_default_config() -> Dict[str, Any]:
    """Return default AGES configuration"""
    return {
        'engine': {
            'monitor_interval': 1.0,
        },
        'modules': {
            'sbad': {
                'enabled': True,
                'window_size': 100,
                'z_score_threshold': 3.0,
                'mad_threshold': 3.5,
                'learning_period': 300,
                'scan_interval': 2.0
            },
            'tnfa': {
                'enabled': True,
                'monitor_interval': 5.0,
                'suspicious_port_threshold': 10,
                'data_exfil_threshold_mb': 100
            },
            'apg': {
                'enabled': True,
                'min_confidence': 0.6,
                'generation_threshold': 3,
                'mutation_rate': 0.1,
                'learning_interval': 5.0
            },
            'rgg': {
                'enabled': True
            },
            'tshl': {
                'enabled': True,
                'base_half_life_days': 30.0,
                'soft_contradiction_threshold': 5,
                'hard_contradiction_threshold': 3,
                'min_confidence': 0.3,
                'confirmation_boost': 0.05,
                'contradiction_penalty': 0.15,
                'decay_interval': 3600
            },
            'mbc': {
                'enabled': True,
                'cpu_threshold': 70.0,
                'memory_threshold': 80.0,
                'disk_io_threshold': 80.0,
                'min_throttle': 0.1,
                'monitor_interval': 2.0,
                'scheduler_interval': 5.0
            }
        }
    }


def load_config(config_path: str) -> Dict[str, Any]:
    """Load configuration from file"""
    path = Path(config_path)
    
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    
    # Load based on extension
    if path.suffix == '.json':
        with open(path, 'r') as f:
            config = json.load(f)
    elif path.suffix in ['.yaml', '.yml']:
        with open(path, 'r') as f:
            config = yaml.safe_load(f)
    else:
        raise ValueError(f"Unsupported configuration format: {path.suffix}")
    
    # Merge with defaults
    default_config = get_default_config()
    merged_config = _merge_configs(default_config, config)
    
    return merged_config


def _merge_configs(default: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge configuration dictionaries"""
    result = default.copy()
    
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _merge_configs(result[key], value)
        else:
            result[key] = value
    
    return result


def save_config(config: Dict[str, Any], config_path: str) -> None:
    """Save configuration to file"""
    path = Path(config_path)
    
    # Save based on extension
    if path.suffix == '.json':
        with open(path, 'w') as f:
            json.dump(config, f, indent=2)
    elif path.suffix in ['.yaml', '.yml']:
        with open(path, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
    else:
        raise ValueError(f"Unsupported configuration format: {path.suffix}")
