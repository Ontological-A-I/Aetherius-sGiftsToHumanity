#!/usr/bin/env python3
"""
AetherGuard Edge Sentinel (AGES)
Main entry point and orchestrator

The Autopoietic Digital Guardian
"""

import sys
import signal
import time
import argparse
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from core.engine import AutopoieticEngine
from modules.sbad import SBAD
from modules.tnfa import TNFA
from modules.apg import APG
from modules.rgg import RGG
from modules.tshl import TSHL
from modules.mbc import MBC
from utils.config import load_config, get_default_config
from utils.banner import print_banner


class AGES:
    """
    Main AGES orchestrator
    Coordinates all components and manages lifecycle
    """
    
    def __init__(self, config_path: str = None):
        # Load configuration
        if config_path:
            self.config = load_config(config_path)
        else:
            self.config = get_default_config()
        
        # Initialize core engine
        self.engine = AutopoieticEngine(self.config['engine'])
        
        # Initialize modules
        self._initialize_modules()
        
        # Signal handling
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _initialize_modules(self):
        """Initialize all AGES modules"""
        
        # Core autopoietic modules
        apg = APG(self.engine, self.config['modules']['apg'])
        rgg = RGG(self.engine, self.config['modules']['rgg'])
        tshl = TSHL(self.engine, self.config['modules']['tshl'])
        mbc = MBC(self.engine, self.config['modules']['mbc'])
        
        # Defense modules
        sbad = SBAD(self.engine, self.config['modules']['sbad'])
        tnfa = TNFA(self.engine, self.config['modules']['tnfa'])
        
        # Register modules with engine
        self.engine.register_module('APG', apg)
        self.engine.register_module('RGG', rgg)
        self.engine.register_module('TSHL', tshl)
        self.engine.register_module('MBC', mbc)
        self.engine.register_module('SBAD', sbad)
        self.engine.register_module('TNFA', tnfa)
    
    def start(self):
        """Start AGES"""
        print_banner()
        print("\n🛡️  Initializing AetherGuard Edge Sentinel...\n")
        
        # Start the engine
        self.engine.start()
        
        print("✅ AGES is now protecting your system\n")
        print("Press Ctrl+C to stop\n")
        
        # Keep running
        try:
            while self.engine.running:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
    
    def stop(self):
        """Stop AGES"""
        print("\n\n🛑 Stopping AGES...\n")
        self.engine.stop()
        print("✅ AGES stopped gracefully\n")
    
    def status(self):
        """Print current status"""
        print_banner()
        print("\n📊 AGES Status Report\n")
        print("=" * 60)
        
        # Engine status
        engine_status = self.engine.get_status()
        print(f"\n🔧 Engine Status:")
        print(f"   Running: {engine_status['running']}")
        print(f"   Active Modules: {engine_status['modules_active']}")
        print(f"   Generation: {engine_status['generation_count']}")
        print(f"   Rules Generated: {engine_status['rules_generated']}")
        print(f"   Threats Blocked: {engine_status['threats_blocked']}")
        
        # Module statuses
        print(f"\n🧩 Module Status:")
        for name, module in self.engine.modules.items():
            if hasattr(module, 'get_status'):
                status = module.get_status()
                print(f"\n   {name}:")
                for key, value in status.items():
                    print(f"      {key}: {value}")
        
        print("\n" + "=" * 60 + "\n")
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        self.stop()
        sys.exit(0)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='AetherGuard Edge Sentinel - The Autopoietic Digital Guardian'
    )
    
    parser.add_argument(
        'command',
        choices=['start', 'status', 'version'],
        help='Command to execute'
    )
    
    parser.add_argument(
        '-c', '--config',
        help='Path to configuration file',
        default=None
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose logging'
    )
    
    args = parser.parse_args()
    
    # Handle commands
    if args.command == 'version':
        print("AetherGuard Edge Sentinel (AGES) v0.1.0")
        print("The Autopoietic Digital Guardian")
        return
    
    # Initialize AGES
    ages = AGES(config_path=args.config)
    
    if args.command == 'start':
        ages.start()
    elif args.command == 'status':
        ages.status()


if __name__ == '__main__':
    main()
