# Protogen - Quick Start Guide

## What You Need

1. **Python 3.7 or newer** installed on your computer
2. **Internet connection** (only for the initial setup to download NetworkX)
3. **No GPU required** - runs perfectly on CPU only

## Installation (3 Simple Steps)

### 1. Extract the Files
Unzip the `protogen_ready_to_run.zip` file to a folder on your computer.

### 2. Install the Required Library
Open a terminal/command prompt in that folder and run:

```bash
pip install -r requirements.txt
```

This installs only NetworkX (a lightweight graph library). **No PyTorch needed!**

### 3. Test It
Run the verification script to make sure everything works:

```bash
python verify_system.py
```

If you see "SYSTEM VERIFICATION COMPLETE" at the end, you're all set!

## What About PyTorch?

**You don't need it.** The system works perfectly without PyTorch. 

The original code tried to use PyTorch for GPU acceleration on AMD cards, but:
- It's optional and often causes compatibility issues
- The CPU-based version using NetworkX works great for this scale
- I've modified the code so it gracefully runs without PyTorch

If you see this message when running the scripts, **that's normal and fine**:
```
--- [INFO]: 'torch' not found. Running in CPU-only mode (this is fine!) ---
```

## How to Use It

The main script is `protogen.py`. You can use it in your own Python programs:

```python
from protogen import OperativeProtogen

# Initialize the AI
ai = OperativeProtogen(root_dir="my_ai_data")

# Feed it some information
ai.ingest_data("Your text data goes here. The AI will extract concepts and build connections.")

# Let it process and organize the knowledge
ai.run_metabolic_cycle()
```

The AI will:
- Extract key concepts from your text
- Build a knowledge graph showing how concepts relate
- Discover patterns and relationships automatically
- Store everything in JSON files you can inspect

## Troubleshooting

**"NetworkX is required"**: Run `pip install networkx`

**"No module named 'protogen'"**: Make sure you're running Python from the folder containing the scripts

**PyTorch errors**: Ignore them! The system doesn't need PyTorch and will use CPU mode automatically.

## What's Different from the Original?

I made these changes to ensure it runs on any computer:

1. **Fixed import statements**: The original files had incorrect import paths
2. **Made PyTorch truly optional**: The system no longer crashes if PyTorch isn't installed
3. **Better error messages**: Clear feedback about what's happening
4. **Minimal dependencies**: Only NetworkX is required (about 5 MB)

## System Requirements

| Component | Requirement |
|-----------|-------------|
| **Python** | 3.7 or newer |
| **RAM** | 2 GB minimum, 4 GB recommended |
| **Disk Space** | 100 MB for code + data |
| **CPU** | Any processor from the last 10 years |
| **GPU** | Not required |
| **Internet** | Only for initial setup |

## File Structure

After running the system, you'll see a `protogen_core` folder created with these files:

- `memory_core.json` - The AI's main state
- `ontology_sqt.json` - The knowledge graph
- `audit_log.json` - Record of all changes
- `telemetry_log.json` - Performance metrics
- `phenomenology_log.json` - Observations
- `trace_log.json` - Lineage tracking
- `quarantine_log.json` - Quarantined data

All files are human-readable JSON, so you can inspect exactly what the AI knows and how it's thinking.

## Next Steps

Read the full `README.md` for more detailed information about:
- How the system works internally
- Advanced configuration options
- Customizing the AI's behavior
- Understanding the knowledge graph structure

Enjoy your lightweight, privacy-focused AI!
