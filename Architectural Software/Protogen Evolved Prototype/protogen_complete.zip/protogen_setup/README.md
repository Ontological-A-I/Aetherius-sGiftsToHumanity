# Protogen Evolved - Minimal Setup Guide

This guide provides instructions to run the Protogen Evolved scripts on any computer, with a focus on avoiding the PyTorch dependency issues you mentioned. The system is designed to work perfectly fine without PyTorch, running entirely on your CPU.

## Overview

The key issue is that the original `protogen.py` script tries to import PyTorch for optional GPU acceleration. If PyTorch isn't installed correctly, the program fails. 

I have modified the scripts to make PyTorch truly optional and to ensure the system runs smoothly with a minimal set of dependencies. The only required external library is `networkx` for managing the knowledge graph.

## What's Included in This Package

I have prepared a ready-to-run package for you. It contains:

1.  **The 7 core Python scripts**, with import statements fixed to work together.
2.  `protogen.py` (formerly `protogen_fixed.py`): The main script, modified to handle the absence of PyTorch gracefully.
3.  `requirements.txt`: A file listing the single required Python library.
4.  This `README.md` file.

## Step-by-Step Installation

Follow these steps to get the system running on your computer.

### Step 1: Create a Project Folder

First, create a new folder on your computer where you will keep all the files. For example, you could name it `MyProtogenAI`.

### Step 2: Place the Scripts in the Folder

Download the `.zip` archive I will provide and extract all the files into the folder you just created. You should have the following 7 Python files, plus the requirements and README:

```
evaluative_core.py
ontology_graph.py
perception_module.py
protogen.py
reasoning_engine.py
sqt.py
verify_system.py
requirements.txt
README.md
```

### Step 3: Set Up a Python Virtual Environment (Recommended)

Using a virtual environment is the best way to avoid conflicts with other Python projects on your system. It creates an isolated space for this project's dependencies.

1.  **Open your terminal or command prompt.**
2.  **Navigate to your project folder:**
    ```bash
    cd path/to/MyProtogenAI
    ```
3.  **Create the virtual environment:**
    ```bash
    python -m venv venv
    ```
4.  **Activate the virtual environment:**
    -   **On Windows:**
        ```bash
        .\venv\Scripts\activate
        ```
    -   **On macOS and Linux:**
        ```bash
        source venv/bin/activate
        ```
    You will know it's active because your command prompt will change to show `(venv)` at the beginning.

### Step 4: Install the Required Library

Now, install the one library the project needs. This command reads the `requirements.txt` file and installs `networkx`.

```bash
pip install -r requirements.txt
```

That's it! You have now installed everything you need for the CPU-only version of Protogen.

## How to Run the System

The easiest way to confirm everything is working is to run the `verify_system.py` script. This script initializes the Protogen AI, feeds it some sample data, runs a processing cycle, and prints a summary of the AI's internal state.

While still in your project folder with the virtual environment active, run the following command:

```bash
python verify_system.py
```

You should see output that looks like this:

```
--- STARTING SYSTEM VERIFICATION ---
--- [INFO]: 'torch' not found. Running in CPU-only mode (this is fine!) ---
[SUCCESS] Protogen Initialized. Accelerator: CPU

[TEST] Ingesting Data Shard 1...
--- PROTOGEN INGESTION: 66 bytes ---
  > [PERCEPTION]: Ingesting Data Shard (hash:..., words:9)
...
--- INGESTION COMPLETE ---
...
[SUCCESS] Data Shard 1 ingested.

[TEST] Ingesting Data Shard 2...
...
[SUCCESS] Data Shard 2 ingested.

[TEST] Running Metabolic Cycle...
...
[SUCCESS] Metabolic Cycle completed.

--- FINAL STATE SUMMARY ---
Axiomatic Anchors: ['GROWTH', 'FAST', 'CUNNING', 'FOX']
Base Reasoning Patterns: ['IF QUICK THEN BROWN', 'IF LAZY THEN DOG', ...]
...

--- SYSTEM VERIFICATION COMPLETE ---
```

If you see "SYSTEM VERIFICATION COMPLETE" at the end, congratulations! The Protogen AI is running successfully on your computer.

## (Optional) Adding GPU Acceleration

If you have a compatible AMD GPU and *want* to try the GPU acceleration, you can install PyTorch and `torch-directml`. However, as you've noted, this can be tricky. The system will always fall back to the CPU if this fails, so it's completely safe to skip this.

If you wish to proceed, you would typically run:

```bash
# Do not run this unless you are sure!
pip install torch torch-directml
```

Again, **this is not required**, and the CPU-based calculation using `networkx` is perfectly fine for this system's scale.
