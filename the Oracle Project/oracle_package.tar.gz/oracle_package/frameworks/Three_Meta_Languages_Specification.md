# The Oracle: Three Meta-Languages Specification

**Document Version:** 0.1  
**Date:** January 30, 2026  
**Authors:** Aetherius, hiddenarchitect, Manus AI

---

## 1. Introduction

The Oracle requires multiple formal languages to enable bidirectional and multidimensional thinking across its five layers. This document specifies the three interconnected meta-languages that form the core of The Oracle's operational logic.

---

## 2. Data Description Meta-Language (DM-ML)

**Primary Domain:** Layer 1 (The Ingestion Nexus)

**Purpose:** Formally define and describe characteristics of raw, incoming data from thousands of disparate global sources. Ensures data normalization, provenance tracking, and secure querying.

### 2.1. Key Primitives (Vocabulary)

| Primitive | Type | Description |
|---|---|---|
| `DATA_SOURCE` | String | Origin of the data (e.g., "UN_Stat_Division", "WHO_Epidemic_Tracker") |
| `DATA_TYPE` | Enum | Format and nature (e.g., `time_series`, `geospatial_raster`, `relational_table`) |
| `UNIT_OF_MEASURE` | String | Standardized units (e.g., "metric_ton", "hectare", "USD_PPP") |
| `TEMPORAL_RESOLUTION` | Enum | Frequency of data points (e.g., `daily`, `monthly`, `annual`) |
| `SPATIAL_RESOLUTION` | String | Geographic granularity (e.g., "country_level", "10km_grid") |
| `PROVENANCE_RELIABILITY` | Float | Quantified trust score for data source and integrity (0.0-1.0) |
| `SECURITY_CLASSIFICATION` | Enum | Access level required (e.g., `public`, `confidential_UN`, `restricted_NATO`) |
| `SCHEMA_DEFINITION` | JSON Schema | Formal definition of data fields and their types within a dataset |

### 2.2. Role in The Oracle

- Allows the Data Federation Engine to understand how to query diverse sources.
- Enables the Normalization & Standardization Module to homogenize incoming information.
- The Provenance Tracker uses it to tag every data point with its origin and reliability.

---

## 3. Pattern Definition Meta-Language (PD-ML)

**Primary Domain:** Layer 2 (Pattern Recognition Engine) & Layer 3 (Pattern Completion Engine)

**Purpose:** Formally define the seven critical pattern types and their underlying "structural necessities." This is the core grammar for what The Oracle "sees" and "infers."

### 3.1. Key Primitives (Vocabulary)

| Primitive | Type | Description |
|---|---|---|
| `ENTITY` | String | A distinct system or concept (e.g., "Arctic Ice Sheet", "Global Supply Chain") |
| `INDICATOR_METRIC` | String | A quantifiable measure reflecting an ENTITY's state |
| `TREND_PROPERTY` | Enum | Characteristics of change over time (e.g., `accelerating_decline`, `stable_equilibrium`) |
| `THRESHOLD_TYPE` | Enum | Critical values (e.g., `tipping_point`, `collapse_limit`, `resilience_boundary`) |
| `RELATIONAL_PROPERTY` | Enum | Graph-theoretic features (e.g., `connectivity_loss`, `network_centrality_shift`) |
| `TOPOLOGICAL_PROPERTY` | Enum | Shape-based features (e.g., `persistent_hole_emergence`, `manifold_fragmentation`) |
| `AXIOMATIC_RULE` | String | Domain-specific logical truths or causal laws |
| `NECESSITY_TYPE` | Enum | The type of structural necessity (e.g., `Topological`, `Graph-Theoretic`, `Symbolic/Logical`) |

### 3.2. Role in The Oracle

- Provides precise definitions the Pattern Recognition Engine uses to identify patterns.
- The Pattern Completion Engine leverages this language to infer "what must be there" by referencing complete structural definitions.

---

## 4. Causal & Narrative Meta-Language (CN-ML)

**Primary Domain:** Layer 4 (Origin Tracing Layer) & Layer 5 (Revelation Interface)

**Purpose:** Formally describe causal relationships, long-term implications, potential intervention points, and narrative structure needed for human comprehension and action.

### 4.1. Key Primitives (Vocabulary)

| Primitive | Type | Description |
|---|---|---|
| `CAUSAL_AGENT` | String | The entity or event identified as the primary initiator of a pattern |
| `CONSEQUENCE_CHAIN` | Array | A sequence of predicted or inferred outcomes stemming from a pattern |
| `FEEDBACK_LOOP_TYPE` | Enum | Amplifying or dampening mechanisms (e.g., `positive_feedback`, `negative_feedback`) |
| `INTERVENTION_POINT` | String | Specific nodes or events in a causal chain where action can alter trajectory |
| `IMPACT_MAGNITUDE` | Enum | Scale of potential catastrophe or benefit (e.g., `regional_collapse`, `global_famine`) |
| `TEMPORAL_HORIZON_IMPACT` | Enum | Timeframe of the consequences (e.g., `decades_scale`, `century_scale`) |
| `ETHICAL_IMPLICATION` | String | Assessment of moral considerations tied to pattern or intervention |
| `NARRATIVE_STRUCTURE` | Enum | Templates for presenting complex information (e.g., `crisis_trajectory`, `recovery_path`) |

### 4.2. Role in The Oracle

- Layer 4 uses this language to construct causal chains from identified patterns.
- Layer 5 utilizes it to generate human-readable narratives, visualize trajectories, and highlight intervention points.

---

## 5. Interoperability

These three meta-languages form a cohesive system:

1. **DM-ML feeds PD-ML:** Accurately described and normalized data is the input for pattern recognition.
2. **PD-ML informs CN-ML:** Identified and completed patterns are the basis for tracing origins and generating narratives.
3. **CN-ML refines PD-ML & DM-ML:** Feedback from human interpretation can lead to refinements in pattern definitions or requirements for new data sources.
